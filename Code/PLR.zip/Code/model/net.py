from torch import nn


class MlpModel(nn.Module):
    def __init__(self, input_dim, num_blocks: [int]):
        super(MlpModel, self).__init__()
        layers = [nn.Linear(input_dim, num_blocks[0])]
        for i in range(1, len(num_blocks)):
            layers.append(nn.Linear(num_blocks[i - 1], num_blocks[i]))
            layers.append(nn.ReLU(inplace=True))
        layers.append(nn.Linear(num_blocks[-1], 1))
        self.linear = nn.Sequential(*layers)

    def forward(self, x):
        return self.linear(x)


class LinearModel(nn.Module):
    def __init__(self, input_dim, num_blocks: [int]):
        super(LinearModel, self).__init__()
        layers = [nn.Linear(input_dim, num_blocks[0])]
        for i in range(1, len(num_blocks)):
            layers.append(nn.Linear(num_blocks[i - 1], num_blocks[i]))
        layers.append(nn.Linear(num_blocks[-1], 1))
        self.linear = nn.Sequential(*layers)

    def forward(self, x):
        return self.linear(x)
