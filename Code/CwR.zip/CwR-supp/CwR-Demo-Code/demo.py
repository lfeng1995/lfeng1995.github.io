import sys
import numpy as np
import scipy
import torch
import torchvision.models
import pandas
import sklearn
import torchvision.transforms as transforms
import torchvision.datasets as dsets
import os
import torchvision.models as models
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as F
from utils_data import *
from utils_algo import *
import utils_data
import utils_algo
import warnings
import argparse

warnings.filterwarnings("ignore")

np.random.seed(0)
torch.manual_seed(0)
torch.cuda.manual_seed_all(0)

parser = argparse.ArgumentParser(
    prog='Demo file for consistent CwR',
    usage='Demo file',
    description='A simple demo file with CIFAR-10 dataset.',
    epilog='end',
    add_help=True)

parser.add_argument('-lr', '--learning_rate', help='optimizer\'s learning rate', default=1e-3, type=float)
parser.add_argument('-bs', '--batch_size', help='batch_size', default=1024, type=int)
parser.add_argument('-e', '--epochs', help='number of epochs', type=int, default=200)
parser.add_argument('-wd', '--weight_decay', help='weight decay', default=1e-4, type=float)
parser.add_argument('-c', '--cost', help='cost', default=1e-1, type=float)

args = parser.parse_args()
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
torch.backends.cudnn.enabled = True
torch.backends.cudnn.benchmark = True
model = []
train_loader, test_loader= utils_data.prepare_CIFAR10_data(batch_size=args.batch_size)
cost = args.cost


for T in range(1):
    model = torchvision.models.resnet34(num_classes=11,pretrained=False)             
    model.to(device)
    optimizer = torch.optim.Adam(model.parameters(), weight_decay=args.weight_decay, lr=args.learning_rate)    
    for epoch in range(1, args.epochs):
        for i, (data, label) in enumerate(train_loader):
            data = data.to(device)
            labels = label.to(device)
            optimizer.zero_grad()
            output = model(data).to(device)
            loss =utils_algo.loss_proposed_GCE(output=output, label=label, cost=args.cost)
            loss.backward()
            optimizer.step()
        err_r, rej_r, test_accuracy = utils_algo.check_01c_proposed(loader=test_loader, model=model, cost=args.cost)
        err_r = err_r.to("cpu")
        rej_r = rej_r.to("cpu")
        test_accuracy = test_accuracy.to("cpu")
        print('Epoch: {}. 0-1-c error: {}'.format(epoch, test_accuracy))
 
