import sys
from data import *
import os


def up_seed(rand_seed):
    """"update seed"""
    torch.manual_seed(rand_seed)
    torch.cuda.manual_seed(rand_seed)
    np.random.seed(rand_seed)
    random.seed(rand_seed)


device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

MAX_INT = sys.maxsize
OPTIM_RATE = [0.001, 0.01]

epoch = 100
optim_rate = OPTIM_RATE[0]

seed = 2023
up_seed(2023)

datasets = {
    "abalone": {"fun_data_processing": abalone_data_processing, "class_dataset": AbaloneDataSet},
    "auto-mpg": {"fun_data_processing": auto_mpg_data_processing, "class_dataset": AutoMpgDataSet},
    "housing": {"fun_data_processing": housing_data_processing, "class_dataset": HousingDataSet},
    "airfoil": {"fun_data_processing": airfoil_data_processing, "class_dataset": AirfoilDataSet},
    "concrete": {"fun_data_processing": concrete_data_processing, "class_dataset": ConcreteDataSet},
    "power-plant": {"fun_data_processing": power_plant_data_processing, "class_dataset": PowerplantDataSet},
    "imdb_wiki": {"fun_data_processing": imdb_wiki_data_processing, "class_dataset": IMDBWIKI},
    "agedb": {"fun_data_processing": AgeDB_data_processing, "class_dataset": AgeDB},
    "sts": {"fun_data_processing": STS_data_processing},
    "optim_rate": optim_rate, "epoch": epoch,
    "num_work": 0, "pin_memory": False, "non_blocking": False, "batch_size": 256, "weight_decay": 0,
    "delta": 5, "lamda": 10,
    "max_interval": 40, "yl": 0, "yr": 200
}


def load_data(data_name, max_interval, time=1, ratio=1, left=-1, right=7):
    if data_name in ["agedb", "imdb_wiki"]:
        df = pd.read_csv(
            "data/dataset/" + data_name + "_split/" + data_name + "_" + str(max_interval) + "_" + str(time) + ".csv",
            sep=",")
        train_data = df.loc[df['split'] == "train"]
        if ratio != 1:
            train_data = slicing(train_data, ratio)
        verify_data = df.loc[df['split'] == "verify"]
        test_data = df.loc[df['split'] == "test"]

        train_interval = train_data[["yl", "yr"]].values
        train_interval = np.float32(train_interval)
        train_number = torch.tensor(range(train_interval.shape[0])).type(torch.long)
        datasets[data_name]["train_dataset"] = datasets[data_name]["class_dataset"](df=train_data,
                                                                                    data_dir="data/dataset",
                                                                                    img_size=224, number=train_number,
                                                                                    interval=train_interval)

        verify_interval = verify_data[["yl", "yr"]].values
        verify_interval = np.float32(verify_interval)
        verify_number = torch.tensor(range(verify_interval.shape[0])).type(torch.long)
        datasets[data_name]["verify_dataset"] = datasets[data_name]["class_dataset"](df=verify_data,
                                                                                     data_dir="data/dataset",
                                                                                     img_size=224, number=verify_number,
                                                                                     interval=verify_interval)

        test_interval = test_data[["yl", "yr"]].values
        test_interval = np.float32(test_interval)
        test_number = torch.tensor(range(test_interval.shape[0])).type(torch.long)
        datasets[data_name]["test_dataset"] = datasets[data_name]["class_dataset"](df=test_data,
                                                                                   data_dir="data/dataset",
                                                                                   img_size=224, number=test_number,
                                                                                   interval=test_interval)
    elif data_name == "sts":
        train_data, test_data, dev_data, vocab, embeddings = STS_data_processing(max_interval, left=left, right=right,
                                                                                 batch=datasets["batch_size"])
        datasets[data_name]["train_dataset"] = train_data
        datasets[data_name]["test_dataset"] = test_data
        datasets[data_name]["verify_dataset"] = dev_data
        datasets[data_name]["vocab"] = vocab
        datasets[data_name]["embeddings"] = embeddings
    else:
        df = pd.read_csv(
            "data/dataset/" + data_name + "_split/" + data_name + "_" + str(max_interval) + "_" + str(
                time) + ".csv",
            sep=",")
        train_data = df.loc[df['split'] == "train"]
        if ratio != 1:
            train_data = slicing(train_data, ratio)
        verify_data = df.loc[df['split'] == "verify"]
        test_data = df.loc[df['split'] == "test"]

        train_interval = train_data[["yl", "yr"]].values
        train_interval = np.float32(train_interval)
        train_number = torch.tensor(range(train_interval.shape[0])).type(torch.long)
        train_data = train_data.values
        train_data = train_data[:, :train_data.shape[1] - 3]
        train_data = np.float32(train_data)
        datasets[data_name]["train_dataset"] = datasets[data_name]["class_dataset"](dataset=train_data,
                                                                                    interval=train_interval,
                                                                                    number=train_number)
        verify_interval = verify_data[["yl", "yr"]].values
        verify_interval = np.float32(verify_interval)
        verify_number = torch.tensor(range(verify_interval.shape[0])).type(torch.long)
        verify_data = verify_data.values
        verify_data = verify_data[:, :verify_data.shape[1] - 3]
        verify_data = np.float32(verify_data)
        datasets[data_name]["verify_dataset"] = datasets[data_name]["class_dataset"](dataset=verify_data,
                                                                                     interval=verify_interval,
                                                                                     number=verify_number)

        test_interval = test_data[["yl", "yr"]].values
        test_interval = np.float32(test_interval)
        test_number = torch.tensor(range(test_interval.shape[0])).type(torch.long)
        test_data = test_data.values
        test_data = test_data[:, :test_data.shape[1] - 3]
        test_data = np.float32(test_data)
        datasets[data_name]["test_dataset"] = datasets[data_name]["class_dataset"](dataset=test_data,
                                                                                   interval=test_interval,
                                                                                   number=test_number)
