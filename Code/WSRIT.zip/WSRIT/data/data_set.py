from torch.utils.data import Dataset
from PIL import Image
import torchvision.transforms as transforms
import numpy as np
import os


class AbaloneDataSet(Dataset):
    def __init__(self, dataset, interval, number):
        super(AbaloneDataSet, self).__init__()
        self.feature = dataset[:, :dataset.shape[1] - 1]
        self.interval = interval
        self.target = dataset[:, -1]
        self.number = number

    def __getitem__(self, index):
        return self.feature[index], self.interval[index], self.target[index], self.number[index]

    def __len__(self):
        return len(self.feature)


class AutoMpgDataSet(Dataset):
    def __init__(self, dataset, interval, number):
        super(AutoMpgDataSet, self).__init__()
        self.feature = dataset[:, 1:]
        self.interval = interval
        self.target = dataset[:, 0]
        self.number = number

    def __getitem__(self, index):
        return self.feature[index], self.interval[index], self.target[index], self.number[index]

    def __len__(self):
        return len(self.feature)


class HousingDataSet(Dataset):
    def __init__(self, dataset, interval, number):
        super(HousingDataSet, self).__init__()
        self.feature = dataset[:, :dataset.shape[1] - 1]
        self.interval = interval
        self.target = dataset[:, -1]
        self.number = number

    def __getitem__(self, index):
        return self.feature[index], self.interval[index], self.target[index], self.number[index]

    def __len__(self):
        return len(self.feature)


class AirfoilDataSet(Dataset):
    def __init__(self, dataset, interval, number):
        super(AirfoilDataSet, self).__init__()
        self.feature = dataset[:, :dataset.shape[1] - 1]
        self.interval = interval
        self.target = dataset[:, - 1]
        self.number = number

    def __getitem__(self, index):
        return self.feature[index], self.interval[index], self.target[index], self.number[index]

    def __len__(self):
        return len(self.feature)


class ConcreteDataSet(Dataset):
    def __init__(self, dataset, interval, number):
        super(ConcreteDataSet, self).__init__()
        self.feature = dataset[:, :dataset.shape[1] - 1]
        self.interval = interval
        self.target = dataset[:, -1]
        self.number = number

    def __getitem__(self, index):
        return self.feature[index], self.interval[index], self.target[index], self.number[index]

    def __len__(self):
        return len(self.feature)


class PowerplantDataSet(Dataset):
    def __init__(self, dataset, interval, number):
        super(PowerplantDataSet, self).__init__()
        self.feature = dataset[:, :dataset.shape[1] - 1]
        self.interval = interval
        self.target = dataset[:, -1]
        self.number = number

    def __getitem__(self, index):
        return self.feature[index], self.interval[index], self.target[index], self.number[index]

    def __len__(self):
        return len(self.feature)


class CpuActDataSet(Dataset):
    def __init__(self, dataset, interval, number):
        super(CpuActDataSet, self).__init__()
        self.feature = dataset[:, :dataset.shape[1] - 1]
        self.interval = interval
        self.target = dataset[:, dataset.shape[1] - 1]
        self.number = number

    def __getitem__(self, index):
        return self.feature[index], self.interval[index], self.target[index], self.number[index]

    def __len__(self):
        return len(self.feature)


class IMDBWIKI(Dataset):
    def __init__(self, df, data_dir, img_size, number, interval, split='train'):
        self.df = df
        self.data_dir = data_dir
        self.img_size = img_size
        self.split = split
        self.label = np.asarray(df['age']).astype('float32')
        self.number = number
        self.interval = interval

    def __len__(self):
        return len(self.df)

    def __getitem__(self, index):
        row = self.df.iloc[index]
        img = Image.open(os.path.join(self.data_dir, row['path'])).convert('RGB')
        transform = self.get_transform()
        img = transform(img)
        return img, self.interval[index], self.label[index], self.number[index]

    def get_transform(self):
        transform = transforms.Compose([
            transforms.Resize((self.img_size, self.img_size)),
            transforms.ToTensor(),
            transforms.Normalize([.5, .5, .5], [.5, .5, .5]),
        ])
        return transform


class AgeDB(Dataset):
    def __init__(self, df, data_dir, img_size, number, interval, split='train'):
        self.df = df
        self.data_dir = data_dir
        self.img_size = img_size
        self.split = split
        self.label = np.asarray(df['age']).astype('float32')
        self.number = number
        self.interval = interval

    def __len__(self):
        return len(self.df)

    def __getitem__(self, index):
        row = self.df.iloc[index]
        img = Image.open(os.path.join(self.data_dir, row['path'])).convert('RGB')
        transform = self.get_transform()
        img = transform(img)
        return img, self.interval[index], self.label[index], self.number[index]

    def get_transform(self):
        if self.split == 'train':
            transform = transforms.Compose([
                transforms.Resize((self.img_size, self.img_size)),
                transforms.RandomCrop(self.img_size, padding=16),
                transforms.RandomHorizontalFlip(),
                transforms.ToTensor(),
                transforms.Normalize([.5, .5, .5], [.5, .5, .5]),
            ])
        else:
            transform = transforms.Compose([
                transforms.Resize((self.img_size, self.img_size)),
                transforms.ToTensor(),
                transforms.Normalize([.5, .5, .5], [.5, .5, .5]),
            ])
        return transform

