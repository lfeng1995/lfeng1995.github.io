import numpy as np
import torch
from utils.utils_data import generate_pcomp_loaders, get_model, generate_pcomp_data
import argparse
from utils.utils_models import linear_model, mlp_model
from utils.utils_loss import logistic_loss
from cifar_models import resnet
from algorithms import *


parser = argparse.ArgumentParser()

parser.add_argument('-lr', help='optimizer\'s learning rate', default=1e-3, type=float)
parser.add_argument('-bs', help='batch_size of ordinary labels.', default=256, type=int)
parser.add_argument('-ds', help='specify a dataset', default='usps', type=str, required=False)
parser.add_argument('-mo', help='model name', default='linear', choices=['linear', 'mlp', 'resnet'], type=str, required=False)
parser.add_argument('-ep', help='number of epochs', type=int, default=100)
parser.add_argument('-wd', help='weight decay', default=1e-5, type=float)
parser.add_argument('-lo', help='specify a loss function', default='logistic', type=str, choices=['logistic'], required=False)
parser.add_argument('-me', help='specify a method', default='PcompTeacher', type=str, choices=['PcompUnbiased','PcompReLU', 'PcompABS',  'PcompTeacher'], required=False)
parser.add_argument('-uci', help = 'Is UCI datasets?', default=1, type=int, choices=[0,1], required=False)
parser.add_argument('-n', help = 'number of unlabeled data pairs', default=15000, type=int, required=False)
parser.add_argument('-prior', help = 'class (positive) prior', default=0.5, type=float, required=False)
parser.add_argument('-gpu', help = 'used gpu id', default='0', type=str, required=False)
parser.add_argument('-ema_weight', help = 'consistency weight', default=10, type=float, required=False)
parser.add_argument('-ema_alpha', help = 'ema variable decay rate', default=0.97, type=float, required=False)

args = parser.parse_args()
device = torch.device("cuda:"+args.gpu if torch.cuda.is_available() else "cpu")

if args.lo == 'logistic':
    loss_fn = logistic_loss

if args.ds == 'usps':
    args.n =2000
elif args.ds == 'pendigits':
    args.n = 2500
elif args.ds =='optdigits':
    args.n = 1000
elif args.ds == 'cnae9':
    args.n = 200
elif args.ds == 'mnist' or args.ds == 'kmnist' or args.ds == 'fashion':
    args.n = 15000
elif args.ds == 'cifar10':
    args.n = 10000
   
xp, xn, real_yp, real_yn, given_yp, given_yn, xt, yt, dim = generate_pcomp_data(args)

#print(xp.shape, xn.shape, real_yp.shape, real_yn.shape, given_yp.shape, given_yn.shape)
pcomp_pos_train_loader, pcomp_neg_train_loader, given_train_loader, real_train_loader, test_loader = generate_pcomp_loaders(xp, xn, given_yp, given_yn, real_yp, real_yn, xt, yt, args.bs)
model = get_model(args, dim, device)


if args.me == 'PcompUnbiased':
    PcompUnbiased_Acc = PcompUnbiased(model, given_train_loader, test_loader, args, loss_fn, device)
    print("PcompUnbiased Accuracy:", PcompUnbiased_Acc)
elif args.me == 'PcompReLU':
    PcompReLU_Acc = PcompReLU(model, given_train_loader, test_loader, args, loss_fn, device)
    print("PcompReLU Accuracy:", PcompReLU_Acc)
elif args.me == 'PcompTeacher':
    ema_model = get_model(args, dim, device)
    PcompTeacher_Acc = PcompTeacher(model, ema_model, given_train_loader, test_loader, args, loss_fn, device)
    print("PcompTeacher Accuracy:", PcompTeacher_Acc)
elif args.me == 'PcompABS':
    PcompABS_Acc = PcompABS(model, given_train_loader, test_loader, args, loss_fn, device)
    print("PcompABS Accuracy:", PcompABS_Acc)

print('method:{}    lr:{}    wd:{}'.format(args.me, args.lr, args.wd))
print('loss:{}    prior:{}'.format(args.lo, args.prior))
print('model:{}    dataset:{}'.format(args.mo, args.ds))
print('num of sample:{}'.format(args.n))
if args.me =='PcompTeacher':
    print('alpha:{}    weight:{}'.format(args.ema_alpha, args.ema_weight))