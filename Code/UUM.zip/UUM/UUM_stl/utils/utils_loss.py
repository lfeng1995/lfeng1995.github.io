from typing import Callable, List

import torch
import torch.nn.functional as F
from torch.distributions import Categorical
import math
from utils.models import sigmoid_activation

def direct_observation_loss(t: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    return F.cross_entropy(t, y)

def norm_softmax(t):
    norm2 = (t*t).sum(-1,keepdim=True) + 1e-7
    t = t/norm2
    return F.softmax(t,dim=-1)

def pairwise_similarity_loss(activation: Callable = None) -> Callable:
    if activation is None:
        activation = lambda t: F.softmax(t, dim=1)

    def loss(ts: List[torch.Tensor], y: torch.Tensor) -> torch.Tensor:
        t1, t2 = ts
        t1 = t1.squeeze()
        t2 = t2.squeeze()
        p_z1 = activation(t1)
        p_z2 = activation(t2)
        p_y1 = (p_z1 * p_z2).sum(dim=1)
        p_y0 = 1. - p_y1
        p_y = torch.stack((p_y0, p_y1), dim=1)
        return F.nll_loss(torch.log(p_y + 1e-32), y)

    return loss




def triplet_comparison_loss(activation: Callable = None) -> Callable:
    if activation is None:
        activation = lambda t: F.softmax(t, dim=1)

    def loss(ts: List[torch.Tensor], y: torch.Tensor) -> torch.Tensor:
        t1, t2, t3 = ts
        t1 = t1.squeeze()
        t2 = t2.squeeze()
        t3 = t3.squeeze()
        p_z1 = activation(t1)
        p_z2 = activation(t2)
        p_z3 = activation(t3)
        p_z12 = (p_z1 * p_z2).sum(dim=1)
        p_z13 = (p_z1 * p_z3).sum(dim=1)
        p_y1 = p_z12 * (1. - p_z13)
        p_y0 = 1. - p_y1
        p_y = torch.stack((p_y0, p_y1), dim=1)
        return F.nll_loss(torch.log(p_y + 1e-32), y)

    return loss


def rc_llp_loss(activation: Callable = None) -> Callable:
    if activation is None:
        activation = lambda t: F.softmax(t, dim=-1)
    def loss(ts: List[torch.Tensor], perm: torch.Tensor, weight: List[torch.Tensor], alpha: float) -> torch.Tensor:
        ts = torch.cat(ts,dim=1)
        p_z = activation(ts)
        loss_z = torch.log(p_z + 1e-32)
        cp_z = p_z.detach()
        
        ts = torch.cat(weight,dim=1)
        p_z = activation(ts)
        
        p_z = alpha * cp_z + (1-alpha) * p_z
        
        aggregate_labels, perm = perm
        
        p_y = perm * p_z.unsqueeze(dim=1)

        p_y = p_y.sum(-1).prod(-1).sum(-1)
        loss_weight = torch.ones_like(loss_z)
        for i in range(ts.size(1)):
            for j in range(p_z.size(-1)):
                temp = perm.clone()
                temp[aggregate_labels[:,:,i]!=j] = 0
                temp = temp * p_z.unsqueeze(1)

                temp = temp.sum(-1).prod(-1).sum(-1)
                loss_weight[:,i,j] = temp
        loss_y = loss_weight * loss_z / (p_y.unsqueeze(-1).unsqueeze(-1) + 1e-32)
        return -loss_y.view(-1).mean()
        
        
    return loss

        

def rc_pairwise_similarity_loss(activation: Callable = None) -> Callable:
    if activation is None:
        activation = lambda t: F.softmax(t, dim=1)
    def loss(ts: List[torch.Tensor], y: torch.Tensor, weight: List[torch.Tensor], alpha:float) -> torch.Tensor:
        t1, t2 = ts
        t1 = t1.squeeze()
        t2 = t2.squeeze()
        
        p_z1 = activation(t1)
        p_z2 = activation(t2)
        
        lossz1 = torch.log(p_z1 + 1e-32)
        lossz2 = torch.log(p_z2 + 1e-32)
        
        cp_z1 = p_z1.detach()
        cp_z2 = p_z2.detach()
        
        t1, t2 = weight
        t1 = t1.squeeze()
        t2 = t2.squeeze()
        
        p_z1 = activation(t1)
        p_z2 = activation(t2)
        
        p_z1 = alpha * cp_z1 + (1-alpha) * p_z1
        p_z2 = alpha * cp_z2 + (1-alpha) * p_z2
        
        p_y1 = (p_z1 * p_z2).sum(dim=1)
        p_y0 = 1. - p_y1
        weight1 = (p_z1 * p_z2)/(p_y1.unsqueeze(-1)+1e-32)
        weight01 = (p_z1 * (1-p_z2))/(p_y0.unsqueeze(-1)+1e-32)
        weight02 = (p_z2 * (1-p_z1))/(p_y0.unsqueeze(-1)+1e-32)
        
        loss11 = (weight1 * lossz1).sum(dim=-1)
        loss12 = (weight1 * lossz2).sum(dim=-1)
        loss01 = (weight01 * lossz1).sum(dim=-1)
        loss02 = (weight02 * lossz2).sum(dim=-1)
        
        loss1 = torch.stack((loss01,loss11),dim=-1)
        loss2 = torch.stack((loss02,loss12),dim=-1)
        
        loss1 = F.nll_loss(loss1,y)
        loss2 = F.nll_loss(loss2,y)
        
        return (loss1+loss2)/2
    return loss


def rc_triplet_comparison_loss(activation: Callable = None) -> Callable:
    if activation is None:
        activation = lambda t: F.softmax(t, dim=1)

    def loss(ts: List[torch.Tensor], y: torch.Tensor,weight: List[torch.Tensor], alpha) -> torch.Tensor:
        t1, t2, t3 = ts
        t1 = t1.squeeze()
        t2 = t2.squeeze()
        t3 = t3.squeeze()

        p_z1 = activation(t1)
        p_z2 = activation(t2)
        p_z3 = activation(t3)
        
        lossz1 = torch.log(p_z1 + 1e-32)
        lossz2 = torch.log(p_z2 + 1e-32)
        lossz3 = torch.log(p_z3 + 1e-32)
        
        cp_z1 = p_z1.detach()
        cp_z2 = p_z2.detach()
        cp_z3 = p_z3.detach()
        
        t1, t2, t3 = weight
        t1 = t1.squeeze()
        t2 = t2.squeeze()
        t3 = t3.squeeze()
        
        p_z1 = activation(t1)
        p_z2 = activation(t2)
        p_z3 = activation(t3)
        
        p_z1 = alpha * cp_z1 + (1-alpha) * p_z1
        p_z2 = alpha * cp_z2 + (1-alpha) * p_z2
        p_z3 = alpha * cp_z3 + (1-alpha) * p_z3
        
        p_z12 = (p_z1 * p_z2).sum(dim=1)
        p_y1 = (p_z1 * p_z2 * (1-p_z3)).sum(dim=-1)
        p_y0 = 1. - p_y1
        
        weight11 = p_z1 * p_z2 * (1-p_z3) / (p_y1.unsqueeze(-1)+1e-32)
        weight12 = p_z2 * p_z1 * (1-p_z3) / (p_y1.unsqueeze(-1)+1e-32)
        weight13 = p_z3 * (p_z12.unsqueeze(-1) - p_z1 * p_z2) / (p_y1.unsqueeze(-1)+1e-32)
        
        weight01 = p_z1 * (1 - p_z2 * (1-p_z3)) / (p_y0.unsqueeze(-1) + 1e-32)
        weight02 = p_z2 * (1 - p_z1 * (1-p_z3)) / (p_y0.unsqueeze(-1) + 1e-32)
        weight03 = p_z3 * (1 - (p_z12.unsqueeze(-1) - p_z1 * p_z2)) / (p_y0.unsqueeze(-1) + 1e-32)
        
        
        
        loss11 = (weight11 * lossz1).sum(dim=-1)
        loss12 = (weight12 * lossz2).sum(dim=-1)
        loss13 = (weight13 * lossz3).sum(dim=-1)
        loss01 = (weight01 * lossz1).sum(dim=-1)
        loss02 = (weight02 * lossz2).sum(dim=-1)
        loss03 = (weight03 * lossz3).sum(dim=-1)
        
        loss1 = torch.stack((loss01,loss11),dim=-1)
        loss2 = torch.stack((loss02,loss12),dim=-1)
        loss3 = torch.stack((loss03,loss13),dim=-1)
        
        loss1 = F.nll_loss(loss1,y)
        loss2 = F.nll_loss(loss2,y)
        loss3 = F.nll_loss(loss3,y)
        
        return (loss1 + loss2 + loss3)/3
    return loss