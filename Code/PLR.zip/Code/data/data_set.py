from torch.utils.data import Dataset


class AbaloneDataSet(Dataset):
    def __init__(self, dataset, candidate_set, num_set, number):
        super(AbaloneDataSet, self).__init__()
        self.feature = dataset[:, :dataset.shape[1] - 1]
        self.candidate_set = candidate_set
        self.target = dataset[:, dataset.shape[1] - 1]
        self.num_set = num_set
        self.number = number

    def __getitem__(self, index):
        return self.feature[index], self.candidate_set[index], self.target[index], self.num_set[index], self.number[index]

    def __len__(self):
        return len(self.feature)


class AutoMpgDataSet(Dataset):
    def __init__(self, dataset, candidate_set, num_set, number):
        super(AutoMpgDataSet, self).__init__()
        self.feature = dataset[:, 1:]
        self.candidate_set = candidate_set
        self.target = dataset[:, 0]
        self.num_set = num_set
        self.number = number

    def __getitem__(self, index):
        return self.feature[index], self.candidate_set[index], self.target[index], self.num_set[index], self.number[index]

    def __len__(self):
        return len(self.feature)


class HousingDataSet(Dataset):
    def __init__(self, dataset, candidate_set, num_set, number):
        super(HousingDataSet, self).__init__()
        self.feature = dataset[:, :dataset.shape[1] - 1]
        self.candidate_set = candidate_set
        self.target = dataset[:, dataset.shape[1] - 1]
        self.num_set = num_set
        self.number = number

    def __getitem__(self, index):
        return self.feature[index], self.candidate_set[index], self.target[index], self.num_set[index], self.number[index]

    def __len__(self):
        return len(self.feature)


class AirfoilDataSet(Dataset):
    def __init__(self, dataset, candidate_set, num_set, number):
        super(AirfoilDataSet, self).__init__()
        self.feature = dataset[:, :dataset.shape[1] - 1]
        self.candidate_set = candidate_set
        self.target = dataset[:, dataset.shape[1] - 1]
        self.num_set = num_set
        self.number = number

    def __getitem__(self, index):
        return self.feature[index], self.candidate_set[index], self.target[index], self.num_set[index], self.number[index]

    def __len__(self):
        return len(self.feature)


class ConcreteDataSet(Dataset):
    def __init__(self, dataset, candidate_set, num_set, number):
        super(ConcreteDataSet, self).__init__()
        self.feature = dataset[:, :dataset.shape[1] - 1]
        self.candidate_set = candidate_set
        self.target = dataset[:, dataset.shape[1] - 1]
        self.num_set = num_set
        self.number = number

    def __getitem__(self, index):
        return self.feature[index], self.candidate_set[index], self.target[index], self.num_set[index], self.number[index]

    def __len__(self):
        return len(self.feature)


class PowerplantDataSet(Dataset):
    def __init__(self, dataset, candidate_set, num_set, number):
        super(PowerplantDataSet, self).__init__()
        self.feature = dataset[:, :dataset.shape[1] - 1]
        self.candidate_set = candidate_set
        self.target = dataset[:, dataset.shape[1] - 1]
        self.num_set = num_set
        self.number = number

    def __getitem__(self, index):
        return self.feature[index], self.candidate_set[index], self.target[index], self.num_set[index], self.number[index]

    def __len__(self):
        return len(self.feature)


class CpuActDataSet(Dataset):
    def __init__(self, dataset, candidate_set, num_set, number):
        super(CpuActDataSet, self).__init__()
        self.feature = dataset[:, :dataset.shape[1] - 1]
        self.candidate_set = candidate_set
        self.target = dataset[:, dataset.shape[1] - 1]
        self.num_set = num_set
        self.number = number

    def __getitem__(self, index):
        return self.feature[index], self.candidate_set[index], self.target[index], self.num_set[index], self.number[index]

    def __len__(self):
        return len(self.feature)
