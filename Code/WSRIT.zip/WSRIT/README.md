# Weakly Supervised Regression with Interval Targets
This is the code for the paper: Weakly Supervised Regression with Interval Targets
## Setups
+ Python 3.7.12
+ Pytorch 1.10.0
+ Numpy 1.21.6
+ Cuda 11.6

## Download Datasets
1. Download AgeDB dataset from [here](https://ibug.doc.ic.ac.uk/resources/agedb/) and extract the zip file (you may need to contact the authors of AgeDB dataset for the zip password). 
2. Download IMDB face book and WIKI face book using data/dataset/download_imdb_wiki.py file.
3. Download STS-B dataset using data/dataset/download_glove.py file.

### Details of STS-B
We process the STS-B dataset following Yang et al. If you need to run demo_sts.py file, you need the following package:
+ nltk
+ wget
+ ipdb
+ scikit-learn
+ allennlp

## Quick Start
You can quickly start with the demo.py file.

You can find the attached code in the paper in the plot.py file
## Generate Interval Dataset
You can generate your own interval data via the generata_interval.py file

We provide multiple interval generation in the data/dataset/**_split. It is worth noting that we do not generate strictly according to the generating distribution in order to satisfy the realistic meaning (avoiding impossible maximum, minimum, negative, etc.), but we still satisfy the assumption that for an instance all possible intervals have equal probability.

## Results
All results are printed in the window by default.

Yang, Y., Zha, K., Chen, Y., Wang, H., and Katabi, D. Delving into deep imbalanced regression. In ICML, pp. 11842–11851, 2021.