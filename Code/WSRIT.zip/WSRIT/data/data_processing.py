import pandas as pd
import numpy as np
import random
import torch
import codecs
import nltk
from collections import defaultdict
from allennlp.data import Instance, Vocabulary, Token
from allennlp.data.fields import TextField
from data.numeric_field import NumericField
from allennlp.data.token_indexers import SingleIdTokenIndexer
from allennlp.data.data_loaders import SimpleDataLoader
from typing import Dict, Iterable, List, Tuple


def gen_uniform_interval(target, maximum_interval, left, right):
    """Generating Weakly Supervised Information via Uniform Distribution"""
    a = np.random.uniform(left, right)
    b = np.random.uniform(left, right)
    while ((b - a) > maximum_interval) or (a > target) or (b < target):
        a = np.random.uniform(left, right)
        b = np.random.uniform(left, right)
    interval = np.array([a, b])
    return interval


def gen_uniform_interval_false(target, maximum_interval, left, right):
    """Generating Weakly Supervised Information via Uniform Distribution"""
    a = np.random.uniform(left, right)
    b = np.random.uniform(left, right)
    while ((b - a) > maximum_interval) or (a > b) or ((a <= target) and (b >= target)):
        a = np.random.uniform(left, right)
        b = np.random.uniform(left, right)
    interval_false = np.array([a, b])
    return interval_false


def check_interval(interval, left, right):
    if len(interval.shape) == 2:
        for i in interval:
            if i[0] < left:
                i[0] = left
            if i[1] > right:
                i[1] = right
    elif len(interval.shape) == 1:
        if interval[0] < left:
            interval[0] = left
        if interval[1] > right:
            interval[1] = right


def cut_list(l, ratio):
    random.shuffle(l)
    length = len(l)
    idx = random.sample(range(length), int(length * ratio))
    l1 = []
    l2 = []
    index = [False for _ in range(length)]
    for i in idx:
        index[i] = True
    for i, j in enumerate(index):
        if j:
            l1.append(l[i])
        else:
            l2.append(l[i])
    return l1, l2


def slicing(df, ratio):
    df = df.reset_index(drop=True)
    l = [i for i in range(len(df))]
    _, l2 = cut_list(l, ratio)
    for i in l2:
        df["split"][i] = "-"
    return df.loc[df['split'] == "train"]


def process_sentence(sent, max_seq_len):
    '''process a sentence using NLTK toolkit'''
    return nltk.word_tokenize(sent)[:max_seq_len]


def load_tsv(data_file, max_seq_len=40, s1_idx=7, s2_idx=8, targ_idx=9, targ_fn=lambda x: np.float32(x), skip_rows=1,
             delimiter='\t'):
    '''Load a tsv '''
    sent1s, sent2s, targs = [], [], []
    with codecs.open(data_file, 'r', 'utf-8') as data_fh:
        for _ in range(skip_rows):
            data_fh.readline()
        for row_idx, row in enumerate(data_fh):
            try:
                row = row.strip().split(delimiter)
                sent1 = process_sentence(row[s1_idx], max_seq_len)
                if (targ_idx is not None and not row[targ_idx]) or not len(sent1):
                    continue

                if targ_idx is not None:
                    targ = targ_fn(row[targ_idx])
                else:
                    targ = 0

                if s2_idx is not None:
                    sent2 = process_sentence(row[s2_idx], max_seq_len)
                    if not len(sent2):
                        continue
                    sent2s.append(sent2)

                sent1s.append(sent1)
                targs.append(targ)

            except Exception as e:
                print(e, " file: %s, row: %d" % (data_file, row_idx))
                continue
    return sent1s, sent2s, targs


def get_words(datas):
    '''
    Get all words for all tasks for all splits for all sentences
    Return dictionary mapping words to frequencies.
    '''
    word2freq = defaultdict(int)

    def count_sentence(sentence):
        '''Update counts for words in the sentence'''
        for word in sentence:
            word2freq[word] += 1
        return

    for data in datas:
        for sentence in data[0]:
            count_sentence(sentence)
        for sentence in data[1]:
            count_sentence(sentence)

    return word2freq


def get_vocab(word2freq, max_v_sizes=30000):
    '''Build vocabulary'''
    vocab = Vocabulary(counter=None, max_vocab_size=max_v_sizes)
    words_by_freq = [(word, freq) for word, freq in word2freq.items()]
    words_by_freq.sort(key=lambda x: x[1], reverse=True)
    for word, _ in words_by_freq[:max_v_sizes]:
        vocab.add_token_to_namespace(word, 'tokens')

    return vocab


def get_embeddings(vocab, vec_file="data/dataset/STS/glove.840B.300d.txt", d_word=300):
    '''Get embeddings for the words in vocab'''
    word_v_size, unk_idx = vocab.get_vocab_size('tokens'), vocab.get_token_index(vocab._oov_token)
    embeddings = np.random.randn(word_v_size, d_word)
    with open(vec_file, encoding='utf-8') as vec_fh:
        for line in vec_fh:
            word, vec = line.split(' ', 1)
            idx = vocab.get_token_index(word)
            if idx != unk_idx:
                idx = vocab.get_token_index(word)
                embeddings[idx] = np.array(list(map(float, vec.split())))
    embeddings[vocab.get_token_index('@@PADDING@@')] = 0.
    embeddings = torch.FloatTensor(embeddings)

    return embeddings


def process_split(split, indexers, max_interval, left, right):
    '''
    Convert a dataset of sentences into padded sequences of indices.
    '''
    inputs1 = [TextField(list(map(Token, sent)), token_indexers=indexers) for sent in split[0]]
    inputs2 = [TextField(list(map(Token, sent)), token_indexers=indexers) for sent in split[1]]
    labels = [NumericField(l) for l in split[-1]]
    intervals = []
    for l in split[-1]:
        interval = gen_uniform_interval(l, max_interval, left, right)
        check_interval(interval, 0, 6)
        intervals.append(NumericField(interval))

    instances = [Instance({"input1": input1, "input2": input2, "label": label, "interval": interval}) for \
                 (input1, input2, label, interval) in zip(inputs1, inputs2, labels, intervals)]

    return instances


def process_task(data, token_indexer, vocab, max_interval, left=-1, right=7):
    '''
    Convert a task's splits into AllenNLP fields then
    Index the splits using the given vocab (experiment dependent)
    '''

    data = process_split(data, token_indexer, max_interval, left, right)

    for instance in data:
        instance.index_fields(vocab)

    return data


def del_field_tokens(data):
    ''' Save memory by deleting the tokens that will no longer be used '''

    for instance in data:
        if 'input1' in instance.fields:
            field = instance.fields['input1']
            del field.tokens
        if 'input2' in instance.fields:
            field = instance.fields['input2']
            del field.tokens


def split(df, max_interval, left, right, path_save):
    label = np.array(df['label']).astype('float32')
    interval = [gen_uniform_interval(x, max_interval, left, right) for x in label]
    interval = np.array(interval)
    df["yl"] = interval[:, 0]
    df["yr"] = interval[:, 1]
    l = [i for i in range(len(df))]
    l1, l2 = cut_list(l, 0.6)
    l2, l3 = cut_list(l2, 0.5)
    df["split"] = "train"
    for i in l2:
        df["split"][i] = "verify"
    for i in l3:
        df["split"][i] = "test"
    df.to_csv(path_save, index=False, sep=",")


def abalone_data_processing(max_interval, left, right, path_load="./data/dataset/abalone.data",
                            path_save="data/dataset/abalone_split"):
    df = pd.read_table(path_load, sep=',')
    df.Rings = df.Rings.astype(float)
    dict_sex = {"M": 0, "F": 1, "I": 2}
    df["Sex"] = df["Sex"].map(dict_sex)
    df["Sex"] = df["Sex"].astype('category')
    data = df.values
    data = np.append(np.eye(3)[data[:, 0].astype(int)], data[:, 1:], axis=1)
    df = pd.DataFrame(data)
    df = df.rename({10: "label"}, axis=1)
    path_save = path_save + "/abalone_" + str(max_interval) + ".csv"
    split(df, max_interval, left, right, path_save)


def auto_mpg_data_processing(max_interval, left, right, path_load="./data/dataset/auto-mpg.data",
                             path_save="data/dataset/auto-mpg_split"):
    df = pd.read_table(path_load, sep='\t')
    df = df.drop(["car name", "Unnamed: 9"], axis=1)
    df = df.dropna()
    dict_cylinders = {3: 0, 4: 1, 5: 2, 6: 3, 8: 4}
    dict_origin = {1: 0, 2: 1, 3: 2}
    df["cylinders"] = df["cylinders"].map(dict_cylinders)
    df["origin"] = df["origin"].map(dict_origin)
    data = df.values
    data = np.append(np.delete(data, 1, axis=1), np.eye(len(dict_cylinders))[data[:, 1].astype(int)], axis=1)
    data = np.append(np.delete(data, 6, axis=1), np.eye(len(dict_origin))[data[:, 6].astype(int)], axis=1)
    df = pd.DataFrame(data)
    df = df.rename({0: "label"}, axis=1)
    path_save = path_save + "/auto-mpg_" + str(max_interval) + ".csv"
    split(df, max_interval, left, right, path_save)


def housing_data_processing(max_interval, left, right, path_load="./data/dataset/housing.data",
                            path_save="data/dataset/housing_split"):
    df = pd.read_table(path_load, sep='\t')
    data = df.values
    data = np.append(np.eye(2)[data[:, 3].astype(int)], np.delete(data, 3, axis=1), axis=1)
    df = pd.DataFrame(data)
    df = df.rename({14: "label"}, axis=1)
    path_save = path_save + "/housing_" + str(max_interval) + ".csv"
    split(df, max_interval, left, right, path_save)


def airfoil_data_processing(max_interval, left, right, path_load="./data/dataset/airfoil.data",
                            path_save="data/dataset/airfoil_split"):
    df = pd.read_table(path_load, sep='\t')
    data = df.values
    data[:, :5] = (data[:, :5] - np.mean(data[:, :5], axis=0)) / np.std(data[:, :5], axis=0)
    df = pd.DataFrame(data)
    df = df.rename({5: "label"}, axis=1)
    path_save = path_save + "/airfoil_" + str(max_interval) + ".csv"
    split(df, max_interval, left, right, path_save)


def concrete_data_processing(max_interval, left, right, path_load="./data/dataset/concrete.data",
                             path_save="data/dataset/concrete_split"):
    df = pd.read_table(path_load, sep=',')
    data = df.values
    df = pd.DataFrame(data)
    df = df.rename({8: "label"}, axis=1)

    path_save = path_save + "/concrete_" + str(max_interval) + ".csv"
    split(df, max_interval, left, right, path_save)


def power_plant_data_processing(max_interval, left, right, path_load="./data/dataset/power-plant.data",
                                path_save="data/dataset/power-plant_split"):
    df = pd.read_table(path_load, sep=',')
    data = df.values
    df = pd.DataFrame(data)
    df = df.rename({4: "label"}, axis=1)

    path_save = path_save + "/power-plant_" + str(max_interval) + ".csv"
    split(df, max_interval, left, right, path_save)


def imdb_wiki_data_processing(max_interval, left, right, path_load='data/dataset/imdb_wiki.csv',
                              path_save="data/dataset/imdb_wiki_split"):
    df = pd.read_csv(path_load)
    label = np.asarray(df['age']).astype('float32')

    interval = [gen_uniform_interval(x, max_interval, left, right) for x in label]
    interval = np.array(interval)
    check_interval(interval, 0, 200)
    df["yl"] = interval[:, 0]
    df["yr"] = interval[:, 1]
    l = [i for i in range(len(df))]
    l1, l2 = cut_list(l, 0.6)
    l2, l3 = cut_list(l2, 0.5)
    df["split"] = "train"
    for i in l2:
        df["split"][i] = "verify"
    for i in l3:
        df["split"][i] = "test"
    path_save = path_save + "/imdb_wiki_" + str(max_interval) + ".csv"
    df.to_csv(path_save, sep=",")


def AgeDB_data_processing(max_interval, left, right, path_load='data/dataset/agedb.csv',
                          path_save="data/dataset/agedb_split"):
    df = pd.read_csv(path_load)
    label = np.asarray(df['age']).astype('float32')

    interval = [gen_uniform_interval(x, max_interval, left, right) for x in label]
    interval = np.array(interval)
    check_interval(interval, 0, 200)
    df["yl"] = interval[:, 0]
    df["yr"] = interval[:, 1]
    l = [i for i in range(len(df))]
    l1, l2 = cut_list(l, 0.6)
    l2, l3 = cut_list(l2, 0.5)
    df["split"] = "train"
    for i in l2:
        df["split"][i] = "verify"
    for i in l3:
        df["split"][i] = "test"
    path_save = path_save + "/agedb_" + str(max_interval) + ".csv"
    df.to_csv(path_save, sep=",")


def build_data_loaders(train_data: List[Instance], epoch):
    train_loader = SimpleDataLoader(train_data, epoch, shuffle=True)
    train_loader.set_target_device(torch.device("cuda:0"))
    return train_loader


def nyu_data_processing(path, max_interval):
    df = pd.read_csv(path, header=None)
    return df


def STS_data_processing(max_interval=4, left=-1, right=7, batch=256):
    train_data = load_tsv("data/dataset/STS/train_new.tsv")
    text_data = load_tsv("data/dataset/STS/test_new.tsv")
    dev_data = load_tsv("data/dataset/STS/dev_new.tsv")
    word2freq = get_words([train_data, text_data, dev_data])
    vocab = get_vocab(word2freq)
    embeddings = get_embeddings(vocab)
    token_indexer = {"words": SingleIdTokenIndexer()}
    train_data = process_task(train_data, token_indexer, vocab, max_interval, left, right)
    text_data = process_task(text_data, token_indexer, vocab, max_interval, left, right)
    dev_data = process_task(dev_data, token_indexer, vocab, max_interval, left, right)
    data = train_data + text_data + dev_data
    train_data, other_data = cut_list(data, 0.6)
    dev_data, text_data = cut_list(other_data, 0.5)
    train_data = build_data_loaders(train_data, batch)
    text_data = build_data_loaders(text_data, batch)
    dev_data = build_data_loaders(dev_data, batch)
    return train_data, text_data, dev_data, vocab, embeddings
