import torch
from scipy.optimize import linear_sum_assignment as hungarian
import torch.nn.functional as F

class confusion:
    def __init__(self,k):
        self.k = k
        self.conf = torch.LongTensor(k,k)
        self.conf.fill_(0)
    
    def reset(self):
        self.conf.fill_(0)
    
    def add(self,output,target):
        #output = output.squeeze()
        target = target.squeeze()
        assert output.size(0) == target.size(0), \
                'number of targets and outputs do not match'
        if output.ndimension()>1: #it is the raw probabilities over classes
            assert output.size(1) == self.conf.size(0) or (output.size(1) ==1 and self.conf.size(0)==2), \
                'number of outputs does not match size of confusion matrix'
            if self.k > 2:
                _,pred = output.max(1) #find the predicted class
            elif self.k == 2:
                pred = (output>0).type(torch.LongTensor).squeeze()
        else: #it is already the predicted class
            pred = output
        indices = (target*self.conf.stride(0) + pred.squeeze_().type_as(target)).type_as(self.conf)
        ones = torch.ones(1).type_as(self.conf).expand(indices.size(0))
        self._conf_flat = self.conf.view(-1)
        self._conf_flat.index_add_(0, indices, ones)
    def optimal_assignment(self):
        mat = -self.conf.cpu().numpy() #hungaian finds the minimum cost
        r,assign = hungarian(mat)
        self.conf = self.conf[:,assign]
        return assign
    def acc(self):
        TP = self.conf.diag().sum().item()
        total = self.conf.sum().item()
        return TP/total

class acc_check:
    def __init__(self,k,opt):
        self.conf = confusion(k)
        self.acc = self.acc_cls
        self.opt = opt
    def acc_cls(self,loader, model, device):
        with torch.no_grad():
            for x, label in loader:
                x, label = x.to(device), label.to(device)
                output = model(x)
                self.conf.add(output,label)
            if self.opt:
                self.conf.optimal_assignment()
            temp = self.conf.acc()
            self.conf.reset()
            return temp
                
                
            
