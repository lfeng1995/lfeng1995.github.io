import numpy as np
from utils_algo import minimax_basis, check_accuracy
from models import linear_model
import torch
import argparse
from convert_to_SDbags import convert_to_SDbags
from algorithms import ConvexApproach, Baselines
from utils_loss import squared_loss, double_hinge_loss, ramp_loss, logistic_loss, hinge_loss, sigmoid_loss
from utils_data import data_processing, Bag

parser = argparse.ArgumentParser()

parser.add_argument('-lr', help='optimizer\'s learning rate', default=1e-3, type=float)
parser.add_argument('-ds', help='specify a dataset', default='elephant', type=str, choices=['musk1','musk2','fox','elephant','tiger','component', 'function', 'process'],required=False)  
parser.add_argument('-me', help='specify a approach', default='CVX_SQ', choices=['CVX_SQ','CVX_DH','BL_SQ', 'BL_DH','BL_RP','BL_LG','BL_HG','BL_SG',], type=str, required=False)
parser.add_argument('-ep', help='number of epochs', default=1000, type=int)
parser.add_argument('-wd', help='weight decay', default=1e-3, type=float)
parser.add_argument('-prior', help='class prior (the ratio of positive bags)', default=0.7, type=float, metavar='[0-1]')
parser.add_argument('-seed', help = 'Random seed', default=1, type=int, required=False)
parser.add_argument('-gpu', help = 'used gpu id', default='0', type=str, required=False)
parser.add_argument('-M', help = 'number of total training bags', default=500, type=int, required=False)
parser.add_argument('-degree', help = 'degree of polynomial kernel', default=1, type=int, required=False)
parser.add_argument('-reg', help = 'regularization parameter', default=1e+2, type=float, required=False)

args = parser.parse_args()
torch.manual_seed(args.seed); torch.cuda.manual_seed_all(args.seed);np.random.seed(args.seed)
device = torch.device("cuda:"+args.gpu if torch.cuda.is_available() else "cpu")

if args.ds == 'musk1':
    num_bags = 92*10
elif args.ds == 'musk2':
    num_bags = 102*10
elif args.ds == 'elephant':
    num_bags = 100*10
elif args.ds == 'fox':
    num_bags = 100*10
elif args.ds == 'tiger':
    num_bags = 100*10
elif args.ds == 'component':
    num_bags = 3130
elif args.ds == 'function':
    num_bags = 5242
elif args.ds == 'process':
    num_bags = 11718
if args.prior == 0.6:
    args.M = 600
elif args.prior == 0.7:
    args.M = 500   
elif args.prior == 0.8:
    args.M = 400 

ordinary_data, dim= data_processing(args.ds,args)
ordinary_bags = [Bag(list(map(lambda X: {'data': X['x'], 'label': X['y']}, list(filter(lambda X: X['bag_id'] == i, ordinary_data)))))
    for i in range(num_bags)] # remove bag_id, and put into Bag()
s1_bags, s2_bags, d1_bags, d2_bags, test_bags = convert_to_SDbags(ordinary_bags, args.prior, args.M, args)

s_bags = s1_bags + s2_bags
d_bags = d1_bags + d2_bags

if args.me == 'CVX_SQ' or args.me == 'CVX_DH':
    train_bags_with_label = s_bags + d_bags # train_bags with label
    train_bags_without_label = list([B.data() for B in train_bags_with_label])
    basis = minimax_basis(train_bags_without_label, args.degree)
    model = ConvexApproach(s_bags, d_bags, basis, args)
    acc = check_accuracy(model, test_bags, aucplot=0)
elif args.me == 'BL_SQ':
    loss_fn = squared_loss
    model = linear_model(input_dim=dim, output_dim=1).to(device)
    acc = Baselines(s_bags, d_bags, test_bags, model, loss_fn,device, args)
elif args.me == 'BL_DH':
    loss_fn = double_hinge_loss
    model = linear_model(input_dim=dim, output_dim=1).to(device)
    acc = Baselines(s_bags, d_bags, test_bags, model, loss_fn,device, args)  
elif args.me == 'BL_RP':
    loss_fn = ramp_loss
    model = linear_model(input_dim=dim, output_dim=1).to(device)
    acc = Baselines(s_bags, d_bags, test_bags, model, loss_fn,device, args) 
elif args.me == 'BL_LG':
    loss_fn = logistic_loss
    model = linear_model(input_dim=dim, output_dim=1).to(device)
    acc = Baselines(s_bags, d_bags, test_bags, model, loss_fn,device, args) 
elif args.me == 'BL_HG':
    loss_fn = hinge_loss
    model = linear_model(input_dim=dim, output_dim=1).to(device)
    acc = Baselines(s_bags, d_bags, test_bags, model, loss_fn,device, args) 
elif args.me == 'BL_SG':
    loss_fn = sigmoid_loss
    model = linear_model(input_dim=dim, output_dim=1).to(device)
    acc = Baselines(s_bags, d_bags, test_bags, model, loss_fn,device, args) 
print("Accuracy for {} on {}: {}".format(args.me, args.ds, acc))

