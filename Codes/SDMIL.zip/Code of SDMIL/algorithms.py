import cvxopt
from cvxopt import matrix
from cvxopt.solvers import qp
cvxopt.solvers.options['show_progress'] = False
import numpy as np
import math
from utils_data import instance_level_train_set
from utils_algo import baseline_accuracy_check
import torch

def Baselines(s_bags, d_bags, test_bags, model, loss_fn,device, args):
    X, y = instance_level_train_set(s_bags, d_bags)
    pos_index = (y==1)
    neg_index = (y==-1)
    pi = args.prior
    theta = args.prior
    theta_S = theta * theta + (1-theta) * (1-theta)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.wd)
    test_acc = baseline_accuracy_check(test_bags=test_bags, model=model, device=device)
    print('iteration: ', 0, 'test accuracy: ', test_acc)
    acc_list = []
    for ep in range(args.ep):
        model.train()
        X = X.to(device)
        output = model(X).cpu()
        s_loss = (((2-pi)*theta_S/(2*theta - 1)) * loss_fn(output[pos_index]) - ((1-pi)*theta_S/(2*theta - 1)) * loss_fn(-output[pos_index])).mean()
        d_loss = ((2*(1-pi)*theta*theta/(2*theta - 1)) * loss_fn(-output[neg_index]) - (2*(theta_S - theta*theta*pi)/(2*theta - 1)) * loss_fn(output[neg_index])).mean()
        train_loss = s_loss + d_loss
        train_loss.backward()
        optimizer.step()
        model.eval()
        test_acc = baseline_accuracy_check(test_bags=test_bags, model=model, device=device)
        if (ep+1)%100 == 0:
            print('iteration: ', ep+1, 'loss:', train_loss.data.numpy(), '  test accuracy: ', test_acc)
        if ep >= args.ep-10:
            acc_list.append([test_acc])
    return np.mean(acc_list)
    
def ConvexApproach(s_bags, d_bags, basis, args):
    
    X_S = list([B.data() for B in s_bags])    #s1_bags + s2_bags # due to the list type
    X_D = list([B.data() for B in d_bags])    #d1_bags + d2_bags

    X_S = np.array([np.r_[1, basis(A)].T for A in X_S]) # X = [1;X]
    X_D = np.array([np.r_[1, basis(B)].T for B in X_D])
    
    N_S = len(X_S)
    N_D = len(X_D)
    theta_S = N_S/(N_S+N_D)
    dim = X_S.shape[1]

    if args.prior >= 0.5:
        est_prior = (1+math.sqrt(2*theta_S-1))/2
    else:
        est_prior = (1-math.sqrt(2*theta_S-1))/2
#    print("Estimated class prior:", est_prior)

    if args.me == 'CVX_SQ':
        return train_sq(X_S, N_S, X_D, N_D, dim, basis, est_prior, theta_S, args.reg)
    elif args.me == 'CVX_DH':
        return train_dh(X_S, N_S, X_D, N_D, dim, basis, est_prior, theta_S, args.reg)


def train_sq(X_S, N_S, X_D, N_D, dim, basis, est_prior, theta_S, reg):
    param = (0.5+(1-est_prior)/(2*est_prior-1))*np.linalg.inv(theta_S/(2*N_S)*X_S.T.dot(X_S) + (1-theta_S)/(2*N_D)*X_D.T.dot(X_D)+reg*np.eye(dim)).dot((theta_S/N_S*X_S.T.dot(np.ones((N_S,1))) - (1-theta_S)/N_D*X_D.T.dot(np.ones((N_D,1)))))
    w = param[1:]
    b = float(param[:1])
    clf = lambda X: w.T.dot(basis(X)) + b
    return clf
def train_dh(X_S, N_S, X_D, N_D, dim, basis, est_prior, theta_S, reg):
    P = np.r_[
            np.c_[reg*np.eye(dim), np.zeros((dim, N_S)), np.zeros((dim, N_D))],
            np.c_[np.zeros((N_S, dim)), np.zeros((N_S, N_S)), np.zeros((N_S, N_D))],
            np.c_[np.zeros((N_D, dim)), np.zeros((N_D, N_S)), np.zeros((N_D, N_D))]
            ]
    q = np.r_[(1-est_prior)/(2*est_prior-1) * (-theta_S/N_S*X_S.T.dot(np.ones((N_S,1)))+(1-theta_S)/N_D*X_D.T.dot(np.ones((N_D,1)))),
              theta_S/N_S*np.ones((N_S,1)),
              (1-theta_S)/N_D*np.ones((N_D,1))]
    G = np.r_[
            np.c_[np.zeros((N_S, dim)), -np.eye(N_S), np.zeros((N_S, N_D))],
            np.c_[-0.5*X_S, -np.eye(N_S), np.zeros((N_S, N_D))],
            np.c_[-X_S, -np.eye(N_S), np.zeros((N_S, N_D))],
            np.c_[np.zeros((N_D, dim)), np.zeros((N_D, N_S)), -np.eye(N_D)],
            np.c_[0.5*X_D, np.zeros((N_D, N_S)), -np.eye(N_D)],
            np.c_[X_D, np.zeros((N_D, N_S)),  -np.eye(N_D)]
            ]
    h = np.r_[np.zeros((N_S,1)), -0.5*np.ones((N_S,1)), np.zeros((N_S,1)), np.zeros((N_D,1)), -0.5*np.ones((N_D,1)), np.zeros((N_D,1))]
    
    result = qp(matrix(P), matrix(q), matrix(G), matrix(h))
    param = np.array(result['x'])
    w = param[1:dim]
    b = float(param[:1])
    clf = lambda X: w.T.dot(basis(X)) + b
    return clf