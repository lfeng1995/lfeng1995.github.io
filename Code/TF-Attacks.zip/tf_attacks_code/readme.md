1- Naturally train a classifier on CIFAR-10 (the dataset will be automatically download).
```python
python train_cifar10.py --train_loss ST
```

2- Construct Poisoning training data.
```python
python make_data_cifar10.py --data_type Poisoning
```

3- Adversarially train classifiers.
```python
python train_cifar10.py --train_loss AT --data_type Quality
python train_cifar10.py --train_loss AT --data_type Poisoning
```

4- Evaluate the performance.
```python
python tf_eval_cifar10.py --train_loss AT --data_type Quality --eval_mode Clean
python tf_eval_cifar10.py --train_loss AT --data_type Quality --eval_mode Hyp
python tf_eval_cifar10.py --train_loss AT --data_type Quality --eval_mode TF
python tf_eval_cifar10.py --train_loss AT --data_type Poisoning --eval_mode Clean
python tf_eval_cifar10.py --train_loss AT --data_type Poisoning --eval_mode Hyp
python tf_eval_cifar10.py --train_loss AT --data_type Poisoning --eval_mode TF
```