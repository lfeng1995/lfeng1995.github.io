import sys
from data import *


def up_seed(rand_seed):
    """"update seed"""
    torch.manual_seed(rand_seed)
    torch.cuda.manual_seed(rand_seed)
    np.random.seed(rand_seed)
    random.seed(rand_seed)


device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
MAX_INT = sys.maxsize

batch_size = 256
MAX_SET = [2, 4, 8, 16]
OPTIM_RATE = [0.001, 0.01]
LOSS_BALANCE = [10, 100, 500, 1000, 10000]
GEN_DATA = gen_uniform

epoch = 1000
max_set = MAX_SET[3]
std = 10
optim_rate = OPTIM_RATE[0]
weights_extreme = -0.5
gen_data = GEN_DATA
loss_balance = LOSS_BALANCE[0]

seed = 2022
up_seed(2022)

datasets = {
    "abalone": {"fun_data_processing": abalone_data_processing, "class_dataset": AbaloneDataSet, "max_set": max_set,
                "std": std, "model_structure": [20, 30, 10], "optim_rate": optim_rate, "epoch": epoch,
                "gen_data_fun": gen_data, "uniform_range": 10, "weights_extreme": weights_extreme,
                "loss_balance": loss_balance, "huber_delta": 1, "c": 4.685, "max_loss_balance": 10000},
    "auto-mpg": {"fun_data_processing": auto_mpg_data_processing, "class_dataset": AutoMpgDataSet,
                 "max_set": MAX_SET[0], "std": std, "model_structure": [20, 30, 10], "optim_rate": optim_rate,
                 "epoch": epoch, "gen_data_fun": gen_data, "uniform_range": 10, "max_loss_balance": 10000,
                 "weights_extreme": weights_extreme, "loss_balance": loss_balance, "huber_delta": 1, "c": 4.685},
    "housing": {"fun_data_processing": housing_data_processing, "class_dataset": HousingDataSet, "max_set": max_set,
                "std": std, "model_structure": [20, 30, 10], "optim_rate": optim_rate, "epoch": epoch,
                "gen_data_fun": gen_data, "uniform_range": 10, "weights_extreme": weights_extreme,
                "loss_balance": loss_balance, "huber_delta": 1, "c": 4.685, "max_loss_balance": 10000},
    "airfoil": {"fun_data_processing": airfoil_data_processing, "class_dataset": AirfoilDataSet, "max_set": max_set,
                "std": std, "model_structure": [20, 30, 10], "optim_rate": optim_rate, "epoch": epoch,
                "gen_data_fun": gen_data, "uniform_range": 10, "weights_extreme": weights_extreme,
                "loss_balance": loss_balance, "huber_delta": 1, "c": 4.685, "max_loss_balance": 10000},
    "concrete": {"fun_data_processing": concrete_data_processing, "class_dataset": ConcreteDataSet,
                 "max_set": max_set, "std": std, "model_structure": [20, 30, 10], "optim_rate": optim_rate,
                 "epoch": epoch, "gen_data_fun": gen_data, "uniform_range": 10, "max_loss_balance": 10000,
                 "weights_extreme": weights_extreme, "loss_balance": loss_balance, "huber_delta": 1, "c": 4.685},
    "power-plant": {"fun_data_processing": power_plant_data_processing, "class_dataset": PowerplantDataSet,
                    "max_set": max_set, "std": std, "model_structure": [20, 30, 10], "optim_rate": optim_rate,
                    "epoch": epoch, "gen_data_fun": gen_data, "uniform_range": 10, "max_loss_balance": 10000,
                    "weights_extreme": weights_extreme, "loss_balance": loss_balance, "huber_delta": 1, "c": 4.685},
    "cpu_act": {"fun_data_processing": cpu_act_data_processing, "class_dataset": CpuActDataSet,
                "max_set": max_set, "std": std, "model_structure": [20, 30, 10], "optim_rate": optim_rate,
                "epoch": epoch, "gen_data_fun": gen_data, "uniform_range": 10, "max_loss_balance": 10000,
                "weights_extreme": weights_extreme, "loss_balance": loss_balance, "huber_delta": 1, "c": 4.685}
}


def up_dataset(data_name, slice=1):
    """update dataset"""
    data_detail = datasets[data_name]
    data, candidate, num_set, number = data_detail["fun_data_processing"](
        "./data/dataset/" + data_name + ".data",
        data_detail["max_set"],
        data_detail["gen_data_fun"],
        data_detail["std"],
        data_detail["uniform_range"])
    data_detail["dataset"] = data_detail["class_dataset"](data, candidate, num_set, number)

    verify_size = int(len(data_detail["dataset"]) * 0.2)
    test_size = int(len(data_detail["dataset"]) * 0.2)
    if slice == 1:
        train_size = int(len(data_detail["dataset"]) * 0.6)
        while train_size + verify_size + test_size != len(data_detail["dataset"]):
            train_size += 1
        data_detail["train_dataset"], data_detail["test_dataset"], data_detail[
            "verify_dataset"] = torch.utils.data.random_split(data_detail["dataset"],
                                                            [train_size, test_size, verify_size])
    else:
        train_size = int(len(data_detail["dataset"]) * 0.6 * slice)
        over_size = len(data_detail["dataset"]) - verify_size - test_size - train_size
        data_detail["train_dataset"], data_detail["test_dataset"], data_detail[
            "verify_dataset"], data_detail["over_dataset"] = torch.utils.data.random_split(data_detail["dataset"],
                                                                                         [train_size, test_size,
                                                                                          verify_size, over_size])
