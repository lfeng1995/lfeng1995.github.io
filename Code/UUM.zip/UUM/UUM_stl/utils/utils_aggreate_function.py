import torch

def similarity_aggreate(labels):
    if labels.shape[1] != 2:
        raise RuntimeError('aggreate function shape not match')
    labels1, labels2 = labels.split(1,1)
    aggreate_labels = (labels1 == labels2).type(torch.LongTensor)
    aggreate_labels.squeeze_(-1)
    return aggreate_labels



    
def Triplet_aggreate(labels):
    if labels.shape[1] != 3:
        raise RuntimeError('aggreate function shape not match')
    labels1, labels2, labels3 = labels.split(1,1)
    labels3 = (labels1==labels3).type(torch.LongTensor)
    labels2 = (labels1==labels2).type(torch.LongTensor)
    aggreate_labels = ((1-labels3)>(1-labels2)).type(torch.LongTensor)
    aggreate_labels.squeeze_(-1)
    return aggreate_labels

def Mil_aggregate(labels):
    aggreate_labels = torch.max(labels,dim=1)[0]
    return aggreate_labels

def Llp_aggregate(labels):
    aggregate_labels = labels
    return aggregate_labels






