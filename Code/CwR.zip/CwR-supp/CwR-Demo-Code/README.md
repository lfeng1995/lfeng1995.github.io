# Generalizing Consistent Multi-Class Classification with Rejection to be Compatible with Arbitrary Losses

## Requirements
- Python 3.6
- numpy 1.14
- PyTorch 1.1
- torchvision 0.2

## Demo
The demo code is an implementation of the proposed surrogate `$L_{c}^{\Phi}$` with constant cost on CIFAR-10 dataset with ResNet-34. The default batch size, epoch number, learning rate, weight decay, and rejection cost are 1024, 200, 1e-3, 1e-4, and 0.1, respectively. We can running the demo code by entering the following command:
```bash
python demo.py 
```

