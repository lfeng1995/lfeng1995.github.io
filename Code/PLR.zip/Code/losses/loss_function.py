import torch.nn.functional as F
import warnings
from parameter import *

warnings.filterwarnings("ignore")


def real_loss(pre, target, *args):
    return F.mse_loss(pre, torch.unsqueeze(target, dim=1))


# ----------------------------------------------------------------------------------------------------------------------
def mse_loss(pre, candidate_set, *args):
    """AVGL-MSE"""
    num_set = args[0]
    mask = torch.tril(torch.ones(candidate_set.shape[1], candidate_set.shape[1]), diagonal=0)[
        (num_set - 1).type(torch.long)]
    mask = mask.to(device)
    return torch.mean(torch.sum(F.mse_loss(pre, candidate_set, reduction='none') * mask, axis=1) / num_set)


# ----------------------------------------------------------------------------------------------------------------------
def mae_loss(pre, candidate_set, *args):
    """AVGL-MAE"""
    num_set = args[0]
    mask = torch.tril(torch.ones(candidate_set.shape[1], candidate_set.shape[1]), diagonal=0)[
        (num_set - 1).type(torch.long)]
    mask = mask.to(device)
    return torch.mean(torch.sum(torch.abs(pre - candidate_set) * mask, axis=1) / num_set)


# ----------------------------------------------------------------------------------------------------------------------
def huber_loss(pre, candidate_set, *args):
    """AVGL-Huber"""
    delta = args[1]
    num_set = args[0]
    mask = torch.tril(torch.ones(candidate_set.shape[1], candidate_set.shape[1]), diagonal=0)[
        (num_set - 1).type(torch.long)]
    mask = mask.to(device)
    mse_1 = F.mse_loss(pre, candidate_set, reduction='none')
    mse_2 = torch.abs(pre - candidate_set)
    loss = torch.where(mse_2 < delta, mse_1 * 0.5, mse_2 * delta - 0.5 * delta * delta) * mask
    return torch.mean(torch.sum(loss, axis=1) / num_set)


# ----------------------------------------------------------------------------------------------------------------------
def avg_mse_loss(pre, candidate_set, *args):
    """AVGV-MSE"""
    num_set = args[0]
    avg = torch.unsqueeze(torch.sum(candidate_set, axis=1) / num_set, axis=1)
    return F.mse_loss(pre, avg)


# ----------------------------------------------------------------------------------------------------------------------
def avg_mae_loss(pre, candidate_set, *args):
    """AVGV-MAE"""
    num_set = args[0]
    avg = torch.unsqueeze(torch.sum(candidate_set, axis=1) / num_set, axis=1)
    loss = torch.nn.L1Loss()
    return loss(pre, avg)


# ----------------------------------------------------------------------------------------------------------------------
def avg_huber_loss(pre, candidate_set, *args):
    """AVGV-Huber"""
    delta = args[1]
    num_set = args[0]
    avg = torch.unsqueeze(torch.sum(candidate_set, axis=1) / num_set, axis=1)
    loss_1 = F.mse_loss(pre, avg, reduction='none')
    loss_2 = torch.abs(pre - avg)
    loss = torch.where(loss_2 < delta, loss_1 * 0.5, loss_2 * delta - 0.5 * delta * delta)
    return torch.mean(loss)


# ----------------------------------------------------------------------------------------------------------------------
def min_loss(pre, candidate_set, *args):
    """IDent"""
    num_set = args[0]
    mask = torch.tril(torch.ones(candidate_set.shape[1], candidate_set.shape[1]), diagonal=0)[
        (num_set - 1).type(torch.long)]
    mask = mask.to(device)
    return torch.mean(
        torch.min((F.mse_loss(pre, candidate_set, reduction='none') * mask + MAX_INT * (1 - mask)), axis=1)[0])


# ----------------------------------------------------------------------------------------------------------------------
def re_weights_loss(pre, candidate_set, *args):
    """PIDent"""
    weights = args[0]
    mse = F.mse_loss(pre, candidate_set, reduction='none')
    return torch.mean(torch.sum(weights * mse, axis=1))


# ----------------------------------------------------------------------------------------------------------------------
def get_weights(feature, candidate_set, model, num_set, b1, b2):
    """Calculate weights"""
    with torch.no_grad():
        pre = model(feature)
        mask = torch.tril(torch.ones(candidate_set.shape[1], candidate_set.shape[1]), diagonal=0)[
            (num_set - 1).type(torch.long)]
        mask = mask.to(device)
        mse = F.mse_loss(pre, candidate_set, reduction='none') + 0.000001
        weight = (mse ** b1) * b2 * mask
        weight = torch.softmax(weight - torch.unsqueeze(torch.max(weight, dim=1)[0], dim=1), dim=1) * mask
        weight = weight / torch.unsqueeze(torch.sum(weight, dim=1), dim=1)
    return weight
