This is the code for the paper: Multiple-Instance Learning from Similar and Dissimilar Bags (KDD 2021).
This repository was implemented by Senlin Shu (shusenlin@126.com).


Requirements:
Python 3.6.13
numpy 1.19.2
Pytorch 1.7.1
cvxopt 1.2.0

DEMO

-ds: specifies the dataset
-me: specifies the method
-lr: learning rate for baselines
-wd: weight decay for baselines
-prior: specifies class prior
-dgree: degree of polynomial kernel
-reg: regularization parameter for our CVX_SQ and CVX_DH

Examples:

python main.py -ds musk1 -me CVX_SQ -degree 1 -reg 100 -prior 0.7
python main.py -ds musk1 -me CVX_DH -degree 1 -reg 1000 -prior 0.7
python main.py -ds musk1 -me BL_SQ -lr 1e-3 -wd 1e-3 -prior 0.7
python main.py -ds musk1 -me BL_DH -lr 1e-3 -wd 1e-1 -prior 0.7

Thank you for your time!