import torch.optim as optim
from losses import *
from model import *
from parameter import *
import copy


def train_model(x, y, model, optimizer, loss_fun, *args):
    model.train()
    optimizer.zero_grad()
    output = model(x)
    loss = loss_fun(output, y, *args)
    loss.backward()
    optimizer.step()
    model.eval()
    return loss.item() * x.shape[0]


def train_dataset_model(dataset, loss_type, model_type="mlp", print_show=True):
    if model_type == "mlp":
        model = MlpModel(len(dataset["train_dataset"].__getitem__(0)[0]), dataset["model_structure"]).to(device)
    elif model_type == "linear":
        model = LinearModel(len(dataset["train_dataset"].__getitem__(0)[0]), dataset["model_structure"]).to(device)
    else:
        print("invalid model")
        sys.exit()

    optimizer = optim.Adam(model.parameters(), lr=dataset["optim_rate"])
    history = [[], []]

    max_loss = MAX_INT
    best_model = copy.deepcopy(model)

    if loss_type == "PIDent":
        weights = \
            torch.tril(torch.ones(dataset["dataset"].candidate_set.shape[1], dataset["dataset"].candidate_set.shape[1]),
                       diagonal=0)[(dataset["dataset"].num_set - 1).type(torch.long)]
        weights = weights / torch.unsqueeze(dataset["dataset"].num_set, axis=1)
        weights = weights.to(device)

    for iter_epoch in range(dataset["epoch"]):
        if print_show:
            print('Epoch {}/{}'.format(iter_epoch + 1, dataset["epoch"]))
        losses_train = 0
        losses_verify = 0
        for i, (feature, candidate, target, num_set, number) in enumerate(
                torch.utils.data.DataLoader(dataset["train_dataset"], batch_size=batch_size)):

            feature, candidate, target, num_set = feature.to(device), candidate.to(device), target.to(
                device), num_set.to(device)

            if loss_type == "AVGL-MSE":
                losses_train += train_model(feature, candidate, model, optimizer, mse_loss, num_set)
            elif loss_type == "AVGL-MAE":
                losses_train += train_model(feature, candidate, model, optimizer, mae_loss, num_set)
            elif loss_type == "AVGL-Huber":
                losses_train += train_model(feature, candidate, model, optimizer, huber_loss, num_set,
                                            dataset["huber_delta"])
            elif loss_type == "IDent":
                losses_train += train_model(feature, candidate, model, optimizer, min_loss, num_set)
            elif loss_type == "PIDent":
                losses_train += train_model(feature, candidate, model, optimizer, re_weights_loss, weights[number])
            elif loss_type == "AVGV-MSE":
                losses_train += train_model(feature, candidate, model, optimizer, avg_mse_loss, num_set)
            elif loss_type == "AVGV-MAE":
                losses_train += train_model(feature, candidate, model, optimizer, avg_mae_loss, num_set)
            elif loss_type == "AVGV-Huber":
                losses_train += train_model(feature, candidate, model, optimizer, avg_huber_loss, num_set,
                                            dataset["huber_delta"])
            elif loss_type == "real":
                losses_train += train_model(feature, target, model, optimizer, real_loss)
            else:
                print("invalid loss function")
                sys.exit()
        if loss_type == "PIDent":
            feature = torch.tensor(dataset["train_dataset"][:][0])
            candidate = torch.tensor(dataset["train_dataset"][:][1])
            num_set = torch.tensor(dataset["train_dataset"][:][3])
            feature, candidate, num_set = feature.to(device), candidate.to(device), num_set.to(device)
            new_weights = get_weights(feature, candidate, model, num_set, dataset["weights_extreme"],
                                      dataset["loss_balance"])
            weights[dataset["train_dataset"][:][4]] = new_weights

        for i, (feature, _, target, _, _) in enumerate(
                torch.utils.data.DataLoader(dataset["verify_dataset"], batch_size=batch_size)):
            feature, target = feature.to(device), target.to(device)
            output = model(feature)
            losses_verify += real_loss(output, target).item() * feature.shape[0]

        if print_show:
            print('Training loss : \t loss_train = {} \t loss_verify = {}'.format(
                losses_train / len(dataset["train_dataset"]),
                losses_verify / len(dataset["verify_dataset"])))

        if (losses_verify / len(dataset["verify_dataset"])) < max_loss:
            """Save the final model or the best model"""
            max_loss = losses_verify / len(dataset["verify_dataset"])
            best_model = copy.deepcopy(model)
        history[0].append(losses_train / len(dataset["train_dataset"]))
        history[1].append(losses_verify / len(dataset["verify_dataset"]))
    return history, best_model


def test_model(model, dataset):
    loss = 0
    for i, (feature, _, target, _, _) in enumerate(
            torch.utils.data.DataLoader(dataset["test_dataset"], batch_size=batch_size)):
        feature, target = feature.to(device), target.to(device)
        output = model(feature)
        loss += real_loss(output, target).item() * feature.shape[0]
    return loss / len(dataset["test_dataset"])
