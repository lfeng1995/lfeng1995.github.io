import numpy as np
import scipy.io as sio
import torch

class Bag(object):
  def __init__(self, instances):
    self.instances = instances
    self.y = min(1, len(list(filter(lambda x: x['label'] == 1, instances)))) * 2 - 1 #create bag label
    self.unlabeled = False

  def __repr__(self):
    return "<Bag #data:{}, label:{}>".format(len(self.instances), self.y)

  def data(self):
    return np.array(list(map(lambda x: x['data'], self.instances)))

  def label(self):
    if self.unlabeled:
      return 0
    else:
      return self.y

  def mask(self):
    self.unlabeled = True

  def add_noise(self):
    m = np.max(list(map(lambda x: x['data'], self.instances)), axis=0)
    for i in range(len(self.instances)):
      z = np.random.normal(0, 0.01, m.shape[0])
      w = np.apply_along_axis(lambda x: 0 if (x == 0).all() else 1, 0, self.instances[i]['data'])
      self.instances[i]['data'] += m * z * w

  def pca_reduction(self, pca):
    for i in range(len(self.instances)):
      self.instances[i]['data'] = pca.transform(self.instances[i]['data'].reshape(1, -1))[0]


def extract_bags(bags, Y, with_label = False):
  if with_label:
    return list(filter(lambda B: B.label() == Y, bags))
  else:
    return list(map(lambda B: B.data(), list(filter(lambda B: B.label() == Y, bags))))


def instance_level_train_set(s_bags, d_bags):   
    for i in range(len(s_bags)):
        if i == 0:
            s_data = s_bags[i].data()
        else:
            s_data = np.r_[s_data, s_bags[i].data()]
    for j in range(len(d_bags)):     
        if j == 0:
            d_data = d_bags[j].data()
        else:
            d_data = np.r_[d_data, d_bags[j].data()] 
    d_labels = -np.ones((len(d_data),1))
    s_labels = np.ones((len(s_data),1))
    train_data = np.r_[s_data,d_data] 
    train_labels = np.r_[s_labels,d_labels]
    train_data = torch.from_numpy(train_data).float()
    train_labels = torch.from_numpy(train_labels).float()
    
    return train_data, train_labels

def file_processing(data_file, dim, num_bags):
    ordinary_data = []
    with open(data_file) as f:
        for l in f.readlines():
            if l[0] == '#':
                continue
            ss = l.strip().split(' ') # ss = ['4776:919:-1', '0:-1.7513811627811062', ...]
# where 4776 means the 4776-th instance, 919 means the 919-th bag, -1 means the label of the instance
            x = np.zeros(dim)
            for s in ss[1:]:
                i, xi = s.split(':') # each index and feature for each instance
                i     = int(i) - 1
                xi    = float(xi) # each feature value
                x[int(i)]  = xi
            _, bag_id, y = ss[0].split(':') # get bid_id and label
            ordinary_data.append({'x': x, 'y': int(y), 'bag_id': int(bag_id)}) # 4777 datum: x, y, bag_id
    return ordinary_data


def load_mat(dataset_name):
    ordinary_set = sio.loadmat('datasets/'+ dataset_name + '.mat')
    data = ordinary_set['data']
    labels = ordinary_set['labels']
    bag_id = ordinary_set['bags_id']
    ordinary_data = []
    dim = data.shape[1]
    for i in range(len(bag_id)):
        x = np.array(data[i])
        y = labels[i]
        index = bag_id[i]
        ordinary_data.append({'x': x, 'y': int(y), 'bag_id': int(index)})
    return ordinary_data, dim


def data_processing(dataset_name,args):
    if dataset_name == 'musk1':
        ordinary_data = file_processing('datasets/musk1.data', 166, 92*10) #920 bags?
        dim = 166
    elif dataset_name == 'musk2':
        ordinary_data = file_processing('datasets/musk2.data', 166, 102*10)
        dim = 166
    elif dataset_name == 'elephant':
        ordinary_data = file_processing('datasets/elephant.data', 230, 200*10)
        dim = 230
    elif dataset_name == 'fox':
        ordinary_data = file_processing('datasets/fox.data', 230, 200*10)
        dim = 230
    elif dataset_name == 'tiger':
        ordinary_data = file_processing('datasets/tiger.data', 230, 200*10)
        dim = 230
    elif dataset_name == 'component' or dataset_name == 'function' or dataset_name == 'process':
        ordinary_data, dim = load_mat(dataset_name)
    return ordinary_data, dim