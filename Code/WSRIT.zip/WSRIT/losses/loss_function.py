import torch
import torch.nn.functional as F
import warnings
from parameter import *
from scipy.stats import gmean, pearsonr

warnings.filterwarnings("ignore")


def real_loss(pre, target):
    return F.mse_loss(pre, torch.unsqueeze(target, dim=1))


# ----------------------------------------------------------------------------------------------------------------------
def real_mae_loss(pre, target):
    target = torch.unsqueeze(target, dim=1)
    return torch.mean(torch.abs(pre - target))


# ----------------------------------------------------------------------------------------------------------------------
def mse_loss(pre, interval):
    """AVGL-MSE"""
    loss = F.mse_loss(pre, interval, reduction='none')
    return torch.mean(loss)


# ----------------------------------------------------------------------------------------------------------------------
def mae_loss(pre, interval):
    """AVGL-MAE"""
    loss = torch.abs(pre - interval)
    return torch.mean(loss)


# ----------------------------------------------------------------------------------------------------------------------
def avg_mse_loss(pre, interval):
    """AVGV-MSE"""
    avg = torch.unsqueeze(torch.sum(interval, dim=1) / 2, dim=1)
    return F.mse_loss(pre, avg)


# ----------------------------------------------------------------------------------------------------------------------
def avg_mae_loss(pre, interval):
    """AVGV-MAE"""
    avg = torch.unsqueeze(torch.sum(interval, dim=1) / 2, dim=1)
    loss = torch.nn.L1Loss()
    return loss(pre, avg)


# ----------------------------------------------------------------------------------------------------------------------
def avg_huber_loss(pre, interval, delta=5):
    """AVGV-Huber"""
    avg = torch.unsqueeze(torch.sum(interval, dim=1) / 2, dim=1)
    loss_1 = F.mse_loss(pre, avg, reduction='none')
    loss_2 = torch.abs(pre - avg)
    loss = torch.where(loss_2 < delta, loss_1 * 0.5, loss_2 * delta - 0.5 * delta * delta)
    return torch.mean(loss)


# ----------------------------------------------------------------------------------------------------------------------
def left_mse_loss(pre, interval):
    """AVGV-MSE"""
    left = torch.unsqueeze(interval[:, 0], dim=1)
    return F.mse_loss(pre, left)


# ----------------------------------------------------------------------------------------------------------------------
def left_mae_loss(pre, interval):
    """AVGV-MAE"""
    left = torch.unsqueeze(interval[:, 0], dim=1)
    loss = torch.nn.L1Loss()
    return loss(pre, left)


# ----------------------------------------------------------------------------------------------------------------------
def left_huber_loss(pre, interval, delta=5):
    """AVGV-Huber"""
    left = torch.unsqueeze(interval[:, 0], dim=1)
    loss_1 = F.mse_loss(pre, left, reduction='none')
    loss_2 = torch.abs(pre - left)
    loss = torch.where(loss_2 < delta, loss_1 * 0.5, loss_2 * delta - 0.5 * delta * delta)
    return torch.mean(loss)


# ----------------------------------------------------------------------------------------------------------------------
def right_mse_loss(pre, interval):
    """AVGV-MSE"""
    right = torch.unsqueeze(interval[:, 1], dim=1)
    return F.mse_loss(pre, right)


# ----------------------------------------------------------------------------------------------------------------------
def right_mae_loss(pre, interval):
    """AVGV-MAE"""
    right = torch.unsqueeze(interval[:, 1], dim=1)
    loss = torch.nn.L1Loss()
    return loss(pre, right)


# ----------------------------------------------------------------------------------------------------------------------
def right_huber_loss(pre, interval, delta=5):
    """AVGV-Huber"""
    right = torch.unsqueeze(interval[:, 1], dim=1)
    loss_1 = F.mse_loss(pre, right, reduction='none')
    loss_2 = torch.abs(pre - right)
    loss = torch.where(loss_2 < delta, loss_1 * 0.5, loss_2 * delta - 0.5 * delta * delta)
    return torch.mean(loss)


# ----------------------------------------------------------------------------------------------------------------------
def l1_mae(pre, interval):
    """LM"""
    loss_1 = torch.unsqueeze(interval[:, 0], dim=1) - pre
    loss_2 = pre - torch.unsqueeze(interval[:, 1], dim=1)
    loss = F.relu(loss_1) + F.relu(loss_2)
    return torch.mean(loss)


# ----------------------------------------------------------------------------------------------------------------------
def correct_rate(pre, interval):
    rate = (pre[:, 0] >= interval[:, 0]) & (pre[:, 0] <= interval[:, 1])
    return torch.sum(rate)


# ----------------------------------------------------------------------------------------------------------------------
def gm(pre, target, step=1):
    target = torch.unsqueeze(target, dim=1)
    criterion_gmean = torch.nn.L1Loss(reduction='none')
    loss = criterion_gmean(pre, target)
    if step:
        return loss
    loss = gmean(np.hstack(loss), axis=None).astype(float)
    return loss


# ----------------------------------------------------------------------------------------------------------------------
def CRM(pre, interval, lamda=0.5):
    yl = torch.unsqueeze(interval[:, 0], dim=1)
    yr = torch.unsqueeze(interval[:, 1], dim=1)
    yl_ = torch.unsqueeze(pre[:, 0], dim=1)
    yr_ = torch.unsqueeze(pre[:, 1], dim=1)
    mid_y = (yr + yl) / 2
    mid_y_ = (yr_ + yl_) / 2
    wid_y = yr - yl
    wid_y_ = yr_ - yl_
    loss = lamda * (mid_y_ - mid_y) * (mid_y_ - mid_y) + (1 - lamda) * (wid_y_ / 2 - wid_y / 2) * (
            wid_y_ / 2 - wid_y / 2)
    return torch.mean(loss)


# ----------------------------------------------------------------------------------------------------------------------
def RANN(pre, interval, lamda=10):
    loss = pre - interval
    loss = loss * loss
    loss = torch.unsqueeze(torch.sum(loss, dim=1), dim=1)
    yl = pre[:, 0]
    yr = pre[:, 1]
    regular = torch.unsqueeze(F.relu(yr - yl), dim=1)
    loss = loss + regular * regular * lamda
    return torch.mean(loss)


# ----------------------------------------------------------------------------------------------------------------------
def SINN(pre, interval, lamda=0.5):
    yl = torch.unsqueeze(interval[:, 0], dim=1)
    yr = torch.unsqueeze(interval[:, 1], dim=1)
    yl_ = torch.unsqueeze(pre[:, 0], dim=1)
    yr_ = torch.unsqueeze(pre[:, 1], dim=1)
    loss = lamda * (yl - yl_) * (yl - yl_) + (1 - lamda) * (yr - yr_) * (yr - yr_)
    return torch.mean(loss)


# ----------------------------------------------------------------------------------------------------------------------
def IN(pre, interval):
    y = torch.unsqueeze(torch.mean(pre, dim=1), dim=1)
    yl = torch.unsqueeze(interval[:, 0], dim=1)
    yr = torch.unsqueeze(interval[:, 1], dim=1)
    loss1 = torch.abs(yr - y)
    loss2 = torch.abs(yl - y)
    condition = loss1 - loss2
    loss = torch.where(condition > 0, loss1, loss2)
    return torch.mean(loss)

# ----------------------------------------------------------------------------------------------------------------------
