This repository provides the implementation for "Pointwise Binary Classification with Pairwise Confidence Comparisons" (ICML 2021).
This repository was implemented by Senlin Shu (shusenlin@126.com).

Requirements:
Python 3.6.13
numpy 1.19.2
Pytorch 1.7.1
torhvision 0.8.2

DEMO

-ds: specifies the dataset
-mo: specifies the model 
-me: specifies the method
-lo: specifies the loss function (default: logistic loss)
-lr: learning rate
-wd: weight decay
-uci: whether using uci datasets
-gpu: specifies gpu id
-prior: specifies class prior
-ema_weight: consistency weight

For example:

python main.py -lo logistic -me PcompTeacher -ep 200 -uci 0 -prior 0.5 -mo mlp -ds mnist -lr 1e-3 -wd 1e-5 -gpu 0 -ema_weight 10
python main.py -lo logistic -me PcompTeacher -ep 200 -uci 0 -prior 0.5 -mo resnet -ds cifar10 -lr 1e-3 -wd 1e-3 -gpu 0 -ema_weight 0.001
python main.py -lo logistic -me PcompTeacher -ep 100 -uci 1 -prior 0.5 -mo linear -ds usps -lr 1e-2 -wd 1e-2 -gpu 0 -ema_weight 0.1




Thank you!
