# Partial-Label Regression
This is the code for the paper: Partial-Label Regression
## Setups
+ Python 3.7.12
+ Pytorch 1.12.0
+ Numpy 1.21.6
+ Cuda 11.6
## Quick Start
You can quickly start with the demo.py file.

You can find the attached code in the paper in the plot.py file
## Result
All results are printed in the window by default.