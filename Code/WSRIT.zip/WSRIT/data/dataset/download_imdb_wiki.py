import os
import wget

imdb_file = "./data/imdb_crop.tar"
wget.download("https://data.vision.ee.ethz.ch/cvl/rrothe/imdb-wiki/static/imdb_crop.tar", out=imdb_file)
wiki_file = "./data/wiki_crop.tar"
wget.download("https://data.vision.ee.ethz.ch/cvl/rrothe/imdb-wiki/static/wiki_crop.tar", out=wiki_file)
os.system(f"tar -xvf {imdb_file} -C ./data")
os.system(f"tar -xvf {wiki_file} -C ./data")
os.remove(imdb_file)
os.remove(wiki_file)