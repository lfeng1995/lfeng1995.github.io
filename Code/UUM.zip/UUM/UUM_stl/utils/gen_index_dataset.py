from torch.utils.data import Dataset

class gen_index_dataset(Dataset):
    def __init__(self, x, labels):
        self.x = x
        self.labels = labels
        
    def __len__(self):
        return len(self.labels)
        
    def __getitem__(self, index):
        each_x = self.x[index]
        each_label = self.labels[index]
        
        return each_x, each_label, index

class ClaDataset(Dataset):
    def __init__(self, x, y):
        self.data = x
        self.y = y
    def __len__(self):
        return len(self.y)
    def __getitem__(self,index):
        return self.data[index], self.y[index]