import torch
import numpy as np
import argparse
import random
import os
from utils.utils_data import prepare_datasets
from utils.utils_loss import rc_mil_loss
from utils.utils_weight import confidence_weight
from utils.models import Linear
from utils.metric import acc_check

parser = argparse.ArgumentParser()
parser.add_argument('-gpu', default='0',help = "used gpu id",type = str )
parser.add_argument('-lr', default=2e-1,help="learning rate for training",type = float )
parser.add_argument('-batch_size', type=int,help = "used batch size for training", default=128)
parser.add_argument('-dataset',type=str,help = "choose the used dataset", choices=['musk1','musk2','elephant','fox','tiger'],default='fox')
parser.add_argument('-seed',type=int,default=0,help = "used random state")
parser.add_argument('-ep',type=int,help = "number of epoch",default=3500)
parser.add_argument('-wd',default=0,help="weight decay",type=float)
parser.add_argument('-init_ep',default=0,help = "initialize epoch",type=int)
parser.add_argument('-alpha',type=float,help="whether to use matrix to stor \eta(x),\
                    0 denotes use matrix, 1 denotes use current model.",default=0)


args = parser.parse_args()
rc_loss_fn = rc_mil_loss()



batch_size = args.batch_size



np.random.seed(args.seed)
torch.manual_seed(args.seed)
torch.cuda.manual_seed_all(args.seed)
random.seed(args.seed)
torch.backends.cudnn.deterministic = True

device = torch.device("cuda:"+args.gpu if torch.cuda.is_available() else "cpu")
print('used device: ' + str(device))
print('seed: '+str(args.seed))

print('generate aggreate dataset')
aggreate_train_loader, val_loader, test_loader, instance_dim, size_m = prepare_datasets(args.dataset,batch_size,args.seed)
K = 2
print('finish generate aggreate dataset')
data_size = aggreate_train_loader.dataset.__len__() + val_loader.dataset.__len__() + test_loader.dataset.__len__()

# set activation function for case k=2
model = Linear(instance_dim).to(device)

weight = confidence_weight(device,data_size,size_m,K)
weight.init_weight(aggreate_train_loader,model,args.init_ep==0)
if args.init_ep>0:
    alpha = 1
else:
    alpha = 0
optimizer = torch.optim.Adam(model.parameters(), lr = args.lr, weight_decay = args.wd)
acc = acc_check(device,size_m)

if K == 2:
    K = 1



print('start training')
best_loss = 0
mo_dict = model.state_dict()
for epoch in range(args.ep):
    if epoch+1>=args.init_ep:
        alpha = args.alpha
    model.train()
    total_loss = 0
    nn = 0
    for i,(x,label,index,mask) in enumerate(aggreate_train_loader):
        x, label, index, mask = x.to(device), label.to(device), index.to(device),mask.to(device)
        x = x.reshape((x.size(0)*size_m,)+x.shape[2:])
        optimizer.zero_grad()
        outputs = model(x)
        outputs = outputs.reshape(-1,size_m,K)
        outputs = outputs.split(1,1)
        loss = rc_loss_fn(outputs,label,weight.get_weight(index),mask,alpha)
        total_loss += loss*x.size(0)
        nn += x.size(0)
        loss.backward()
        optimizer.step()
        weight.update_weight(model,x,index)
    model.eval()
    temp = torch.ones_like(x)
    val_loss = acc.acc(val_loader,model,device)
    if val_loss >= best_loss:
        best_loss = val_loss
        torch.save(model.state_dict(),'data/model/{}dict.pth'.format(os.getpid()))
    if (epoch+1)%100==0:
        train_acc = acc.acc(aggreate_train_loader,model,device)
        val_acc = acc.acc(val_loader,model,device)
        print('Epoch: {}. Tr Acc: {}. Val Acc: {}.'.format(epoch+1, train_acc, val_acc))
        print('total loss: {}'.format(total_loss/nn))
model.load_state_dict(torch.load('data/model/{}dict.pth'.format(os.getpid())))
print('best Val acc:{}. Te acc:{}'.format(acc.acc(val_loader,model,device),acc.acc(test_loader,model,device)))