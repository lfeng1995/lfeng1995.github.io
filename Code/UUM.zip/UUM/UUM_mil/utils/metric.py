import torch
from scipy.optimize import linear_sum_assignment as hungarian
import torch.nn.functional as F


class acc_check():
    def __init__(self,device,size_m):
        self.device = device
        self.size_m = size_m
    def acc(self,loader, model, device):
        with torch.no_grad():
            total = 0
            correct = 0
            for x, label, index, mask in loader:
                x, label, mask = x.to(device), label.to(device), mask.to(device)
                x = x.reshape((x.size(0)*self.size_m,)+x.shape[2:])
                outputs = model(x)
                outputs = outputs.reshape(-1,self.size_m)
                outputs[mask==0] = -1
                predict = (outputs>0).type(torch.LongTensor).to(device)
                predict = predict.max(dim=1)[0]
                correct += torch.sum(predict==label)
                total += outputs.size(0)
            return correct/total
                
            
