# Exploiting Human-AI Dependency for Learning to Defer
This is the code demo of CIFAR100 for the paper: Exploiting Human-AI Dependency for Learning to Defer
## Requirements
+ Python 3.6.13
+ Pytorch 1.7.1
+ Numpy 1.19.2
+ Cuda 12.2

## Demo
You could to train a classifier first with the following command:
```bash
python -m torch.distributed.launch --nproc_per_node=8 --master_port 29617 demo.py
```
The statistics shown in the experiments will be printed in each epoch.
