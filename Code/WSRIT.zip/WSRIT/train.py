import torch.optim as optim
from losses import *
from model import *
from parameter import *
import copy


def train_dataset_model(dataset_name, loss_type, model_type="mlp", metrics=None, print_show=False, out_dim=1):
    if metrics is None:
        metrics = ["mse"]
    if model_type == "mlp":
        model = MlpModel(len(datasets[dataset_name]["train_dataset"].__getitem__(0)[0]), out_dim=out_dim)
    elif model_type == "linear":
        model = LinearModel(len(datasets[dataset_name]["train_dataset"].__getitem__(0)[0]), out_dim=out_dim)
    elif model_type == "ResNet":
        model = ResNet(Bottleneck, [3, 4, 6, 3], out_dim=out_dim)
    else:
        print("invalid model")
        sys.exit()
    if torch.cuda.device_count() > 1:
        model = torch.nn.DataParallel(model).cuda()
    else:
        model = model.cuda()
    optimizer = optim.Adam(model.parameters(), lr=datasets["optim_rate"], betas=(0.9, 0.999), eps=1e-08,
                           weight_decay=datasets["weight_decay"])

    best_model = {}
    max_loss = {}
    for metric in metrics:
        best_model[metric] = copy.deepcopy(model)
        if metric in ["mse", "mae", "gm"]:
            max_loss[metric] = MAX_INT
        elif metric in ["pearsonr"]:
            max_loss[metric] = 0

    for iter_epoch in range(datasets["epoch"]):
        if print_show:
            print('Epoch {}/{}'.format(iter_epoch + 1, datasets["epoch"]))
        losses_train = 0
        for i, (feature, interval, target, number) in enumerate(
                torch.utils.data.DataLoader(datasets[dataset_name]["train_dataset"],
                                            batch_size=datasets["batch_size"],
                                            num_workers=datasets["num_work"], pin_memory=datasets["pin_memory"])):

            feature, interval, target = feature.cuda(non_blocking=datasets["non_blocking"]), interval.cuda(
                non_blocking=datasets["non_blocking"]), target.cuda(non_blocking=datasets["non_blocking"])

            model.train()
            optimizer.zero_grad()
            output = model(feature)

            if loss_type == "real":
                loss = real_loss(output, target)
            elif loss_type == "lm":
                loss = l1_mae(output, interval)
            elif loss_type == "mse_loss":
                loss = mse_loss(output, interval)
            elif loss_type == "mae_loss":
                loss = mae_loss(output, interval)
            elif loss_type == "avg_mse_loss":
                loss = avg_mse_loss(output, interval)
            elif loss_type == "avg_mae_loss":
                loss = avg_mae_loss(output, interval)
            elif loss_type == "avg_huber_loss":
                loss = avg_huber_loss(output, interval, datasets["delta"])
            elif loss_type == "left_mse_loss":
                loss = left_mse_loss(output, interval)
            elif loss_type == "left_mae_loss":
                loss = left_mae_loss(output, interval)
            elif loss_type == "left_huber_loss":
                loss = left_huber_loss(output, interval, datasets["delta"])
            elif loss_type == "right_mse_loss":
                loss = right_mse_loss(output, interval)
            elif loss_type == "right_mae_loss":
                loss = right_mae_loss(output, interval)
            elif loss_type == "right_huber_loss":
                loss = right_huber_loss(output, interval, datasets["delta"])

            elif loss_type == "RANN":
                loss = RANN(output, interval, datasets["lamda"])
            elif loss_type == "CRM":
                loss = CRM(output, interval, datasets["lamda"])
            elif loss_type == "SINN":
                loss = SINN(output, interval, datasets["lamda"])
            elif loss_type == "IN":
                loss = IN(output, interval)
            else:
                print("invalid loss function")
                sys.exit()
            loss.backward()
            optimizer.step()
            model.eval()
            losses_train += loss.item() * feature.shape[0]

        verify = {}
        for metric in metrics:
            verify[metric] = 0
        if "gm" in metrics:
            loss_gm = []
        if "pearsonr" in metrics:
            loss_pearsonr = []
            target_pearsonr = []

        for i, (feature, interval, target, _) in enumerate(
                torch.utils.data.DataLoader(datasets[dataset_name]["verify_dataset"],
                                            batch_size=datasets["batch_size"],
                                            num_workers=datasets["num_work"], pin_memory=datasets["pin_memory"])):
            feature, interval, target = feature.cuda(non_blocking=datasets["non_blocking"]), interval.cuda(
                non_blocking=datasets["non_blocking"]), target.cuda(
                non_blocking=datasets["non_blocking"])
            output = model(feature)
            if out_dim == 2:
                output = torch.unsqueeze(torch.mean(output, dim=1), dim=1)
            for metric in metrics:
                if metric == "mse":
                    verify[metric] += real_loss(output, target).item() * interval.shape[0]
                elif metric == "mae":
                    verify[metric] += real_mae_loss(output, target).item() * interval.shape[0]
                elif metric == "gm":
                    l = gm(output, target, step=1).cpu()
                    l = l.detach().numpy()
                    loss_gm.extend(l)
                elif metric == "pearsonr":
                    loss_pearsonr.extend(output.cpu().detach().numpy())
                    target_pearsonr.extend(target.cpu().numpy())
        if "gm" in metrics:
            verify["gm"] = gmean(np.hstack(loss_gm), axis=None).astype(float)
        if "pearsonr" in metrics:
            verify["pearsonr"] = pearsonr(np.hstack(loss_pearsonr), np.hstack(target_pearsonr))[0]
        for metric in metrics:
            if metric not in ["gm", "pearsonr"]:
                verify[metric] = verify[metric] / len(datasets[dataset_name]["verify_dataset"])

        if print_show:
            print('Training loss : \t loss_train = {}\t verify = {}'.format(
                losses_train / len(datasets[dataset_name]["train_dataset"]), verify))

        for metric in metrics:
            if metric in ["mse", "mae", "gm"]:
                if verify[metric] <= max_loss[metric]:
                    best_model[metric] = copy.deepcopy(model)
                    max_loss[metric] = verify[metric]
            if metric in ["pearsonr"]:
                if verify[metric] >= max_loss[metric]:
                    best_model[metric] = copy.deepcopy(model)
                    max_loss[metric] = verify[metric]

    return best_model


def test_model(model, dataset_name, metrics, out_dim=1):
    model.eval()
    test = {}
    for metric in metrics:
        test[metric] = 0

    if "gm" in metrics:
        loss_gm = []
    if "pearsonr" in metrics:
        loss_pearsonr = []
        target_pearsonr = []
    for i, (feature, _, target, _) in enumerate(
            torch.utils.data.DataLoader(datasets[dataset_name]["test_dataset"],
                                        batch_size=datasets["batch_size"],
                                        num_workers=datasets["num_work"], pin_memory=datasets["pin_memory"])):
        feature, target = feature.cuda(non_blocking=datasets["non_blocking"]), target.cuda(
            non_blocking=datasets["non_blocking"])
        output = model(feature)
        if out_dim == 2:
            output = torch.unsqueeze(torch.mean(output, dim=1), dim=1)
        for metric in metrics:
            if metric == "mse":
                test[metric] += real_loss(output, target).item() * feature.shape[0]
            elif metric == "mae":
                test[metric] += real_mae_loss(output, target).item() * feature.shape[0]
            elif metric == "gm":
                l = gm(output, target, step=1)
                loss_gm.extend(l.cpu().detach().numpy())
            elif metric == "pearsonr":
                loss_pearsonr.extend(output.cpu().detach().numpy())
                target_pearsonr.extend(target.cpu().numpy())
    if "gm" in metrics:
        test["gm"] = gmean(np.hstack(loss_gm), axis=None).astype(float)
    if "pearsonr" in metrics:
        test["pearsonr"] = pearsonr(np.hstack(loss_pearsonr), np.hstack(target_pearsonr))[0]
    for metric in metrics:
        if metric not in ["gm", "pearsonr"]:
            test[metric] = test[metric] / len(datasets[dataset_name]["test_dataset"])
    return test
