import torch
import numpy as np
import argparse
import random
import os
from utils.gen_index_dataset import gen_index_dataset
from utils.utils_data import prepare_datasets,generate_aggreate_dataset
from utils.utils_aggreate_function import similarity_aggreate, Triplet_aggreate
from utils.utils_aggreate_function import Llp_aggregate
from utils.utils_loss import pairwise_similarity_loss, triplet_comparison_loss, rc_pairwise_similarity_loss, rc_triplet_comparison_loss
from utils.utils_loss import rc_llp_loss
from utils.utils_weight import confidence_weight
from utils.utils_perm import LLP_perm
from utils.models import LeNet
from utils.cifar_models import densenet
from utils.metric import acc_check

parser = argparse.ArgumentParser()
parser.add_argument('-gpu', default='0',help="used gpu id",type = str )
parser.add_argument('-lr', default=1e-3,help="optimizer's learning rate",type = float )
parser.add_argument('-task', type=str,help = 'learning from which CFAO tasks', choices=['similarity','triplet','llp'], default="similarity")
parser.add_argument('-batch_size', type=int,help = "batch size of aggregate labels", default=128)
parser.add_argument('-data_size',type=int,help=" the number of groups sampled",default=120000)
parser.add_argument('-size_m',type=int,help="size of bag, note that the size for similarity is 2 and for triplet is 3",default=6)
parser.add_argument('-dataset',type=str,default="mnist", help="specify a dataset",choices=['mnist','kmnist','fashion','cifar10','SVHN'])
parser.add_argument('-so',help="option of select sample", type=str, choices=['rep','nrep','nrep_within_set'],default = 'rep',required=False)
parser.add_argument('-seed',type=int,help = "Random seed", default=0)
parser.add_argument('-ep',type=int,help = "number of epochs",default=100)
parser.add_argument('-wd',default=0,help="wegiht_decay",type=float)
parser.add_argument('-init_ep',default=20,help="number of warm-up epoch",type=int)
parser.add_argument('-cc_init',action = 'store_true',help="whether to use log-likelihood to warmup")
parser.add_argument('-alpha',type=float,help="whether to use matrix to stor \eta(x),\
                    0 denotes use matrix, 1 denotes use current model. if cc_init is set to False, then the first ep_init epoch would set alpha as 1",default=0)
args = parser.parse_args()

if args.task == 'similarity':
    size_m = 2
    aggreate_function = similarity_aggreate
    rc_loss_fn = rc_pairwise_similarity_loss()
    cc_loss_fn = pairwise_similarity_loss()
elif args.task == 'triplet':
    size_m = 3
    aggreate_function = Triplet_aggreate
    rc_loss_fn = rc_triplet_comparison_loss()
    cc_loss_fn = triplet_comparison_loss()
elif args.task == 'llp':
    size_m = args.size_m
    aggreate_function = Llp_aggregate
    rc_loss_fn = rc_llp_loss()


data_size = args.data_size
batch_size = args.batch_size



np.random.seed(args.seed)
torch.manual_seed(args.seed)
torch.cuda.manual_seed_all(args.seed)
random.seed(args.seed)
torch.backends.cudnn.deterministic = True

device = torch.device("cuda:"+args.gpu if torch.cuda.is_available() else "cpu")
print('used device: ' + str(device))
print('seed: '+str(args.seed))

print('generate aggreate dataset')
train_loader, val_loader, test_loader, full_train_loader, instance_dim, K = prepare_datasets(args.dataset,batch_size,args.seed)
if args.dataset in ['abalone','deter','dna','letter','msplice','optdigits','pendigits',\
                    'texture','usps','vehicle','waveform']:
    if args.task in ['similarity','triplet']:
        data_size = (train_loader.dataset.__len__()+val_loader.dataset.__len__()+test_loader.dataset.__len__())*2
    else:
        data_size = (train_loader.dataset.__len__()+val_loader.dataset.__len__()+test_loader.dataset.__len__())//2
data, aggreate_labels= generate_aggreate_dataset(full_train_loader,data_size,size_m,args.so,aggreate_function,args.task)
aggreate_dataset = gen_index_dataset(data,aggreate_labels)
aggreate_train_loader = torch.utils.data.DataLoader(dataset=aggreate_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
print('finish generate aggreate dataset')

if args.task == 'llp':
    print('generate permutation for llp')
    llp_perm = LLP_perm(aggreate_labels,device,K)
    print('finished generate permutation')


if args.dataset in ['cifar10','SVHN']:
    model = densenet(num_classes=K).to(device)
else:
    model = LeNet(K).to(device)
    
weight = confidence_weight(device,data_size,size_m,K)
weight.init_weight(aggreate_train_loader,model,args.task=='llp')
if args.init_ep >0:
    alpha = 1
else: 
    alpha = 0 
optimizer = torch.optim.Adam(model.parameters(), lr = args.lr, weight_decay = args.wd)
acc = acc_check(K,args.task in ['similarity','triplet'])



print('start training')
best_loss = 0
mo_dict = model.state_dict()
for epoch in range(args.ep):
    model.train()
    total_loss = 0
    nn = 0
    for i,(x,label,index) in enumerate(aggreate_train_loader):
        x, label, index = x.to(device), label.to(device), index.to(device)
        if args.task == 'llp':
            label = llp_perm.get_perm(index)
        x = x.reshape((x.size(0)*size_m,)+x.shape[2:])
        optimizer.zero_grad()
        outputs = model(x)
        outputs = outputs.reshape(-1,size_m,K)
        outputs = outputs.split(1,1)
        if args.cc_init and epoch+1<=args.init_ep:
            loss = cc_loss_fn(outputs,label)
        else:
            loss = rc_loss_fn(outputs,label,weight.get_weight(index),alpha)
        total_loss += loss*x.size(0)
        nn += x.size(0)
        loss.backward()
        optimizer.step()
        weight.update_weight(model,x,index)
    model.eval()
    temp = torch.ones_like(x)
    if epoch+1==args.init_ep:
        alpha = args.alpha
    val_loss = acc.acc(val_loader,model,device)
    if val_loss > best_loss:
        best_loss = val_loss
        torch.save(model.state_dict(),'data/model/{}dict.pth'.format(os.getpid()))
    train_acc = acc.acc(train_loader,model,device)
    val_acc = acc.acc(val_loader,model,device)
    print('Epoch: {}. Tr Acc: {}. Val Acc: {}.'.format(epoch+1, train_acc, val_acc))
    print('total loss: {}'.format(total_loss/nn))
model.load_state_dict(torch.load('data/model/{}dict.pth'.format(os.getpid())))
print('best Val acc:{}. Te acc:{}'.format(args.seed,acc.acc(val_loader,model,device),acc.acc(test_loader,model,device)))