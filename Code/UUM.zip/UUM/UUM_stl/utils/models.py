from torch import nn
import torch.nn.functional as F
import torch


def sigmoid_activation(ts):
    p1 = torch.sigmoid(ts)
    p0 = 1-p1
    return torch.stack((p0,p1),dim=-1)


class LeNet(nn.Module):
    def __init__(self, output_dim):
        if output_dim == 2:
            output_dim = 1
        super(LeNet, self).__init__()
        self.conv1 = nn.Conv2d(1, 6, 5, padding=2)
        self.conv2 = nn.Conv2d(6, 16, 5)
        self.fc1   = nn.Linear(16*5*5, 120)
        self.fc2   = nn.Linear(120, 84)
        self.fc3   = nn.Linear(84, output_dim)

    def forward(self, x):
        out = F.relu(self.conv1(x))
        out = F.max_pool2d(out, (2,2))
        out = F.relu(self.conv2(out))
        out = F.max_pool2d(out, (2,2))
        out = out.view(out.size(0), -1)
        out = F.relu(self.fc1(out))
        out = F.relu(self.fc2(out))
        out = self.fc3(out)
        return out


class MLP(nn.Module):
    def __init__(self,dim_input,dim_output):
        super(MLP,self).__init__()
        if dim_output == 2:
            dim_output = 1
        self.linear1 = nn.Linear(dim_input,300)
        self.linear2 = nn.Linear(300,dim_output)
    def forward(self,x):
        outputs = self.linear1(x)
        outputs = torch.relu(outputs)
        outputs = self.linear2(outputs)
        return outputs