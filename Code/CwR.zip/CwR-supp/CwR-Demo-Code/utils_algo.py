import sys
import numpy as np
import scipy
import torch
import pandas
import sklearn
import torchvision.transforms as transforms
import torchvision.datasets as dsets
import torchvision.models as models
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as F
import warnings
import argparse


np.random.seed(0)
torch.manual_seed(0)
torch.cuda.manual_seed_all(0)
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def loss_proposed_GCE(cost, output, label):
    output = output.to(device)
    label = label.to(device)
    label_rej = 0*label + 10
    label_rej = label_rej.to(device)
    probit = F.softmax(output, dim=-1).to(device)+1e-18
    q=0.7
    
    loss_vector_acc = (1-torch.pow(probit.gather(-1, label.view(-1, 1)).to(device), q))/q
    loss_vector_acc = loss_vector_acc.to(device)
    
    loss_vector_rej = (1-torch.pow(probit.gather(-1, label_rej.view(-1, 1)).to(device), q))/q
    loss_vector_rej = loss_vector_rej.to(device)
    
    loss_vector = (loss_vector_acc+(1-cost)*loss_vector_rej).to(device)    
    loss = torch.mean(loss_vector).to(device)
    
    return loss


def check_01c_proposed(cost, loader, model):
    model = model.to(device)
    error_count=0
    rejection_count=0   
    sum=0
    for i, (data, label) in enumerate(loader):
      sum+=len(label)
      data = data.to(device)
      label = label.to(device)
      output = model(data).to(device)
      (value, prediction) = torch.max(output, dim=-1)
      prediction = prediction.to(device)
      acc_list = prediction != 10
      reject_list = prediction == 10
      error_list = prediction.view(-1, 1) != label.view(-1, 1)
      error_list = torch.mul(error_list.view(-1,1), acc_list.view(-1,1)).to(device)
      error_count += torch.sum(error_list).to(device)
      rejection_count += torch.sum(reject_list).to(device)
    print('Error rate: {:.3f}. Rejection rate: {:.3f}'.format(error_count/(sum-rejection_count), rejection_count/sum))
    error_01c = (error_count+rejection_count*cost).to(device)
    error = error_01c/sum
    err_r = error_count/(sum-rejection_count)
    rej_r = rejection_count/sum 
    return err_r, rej_r, error
