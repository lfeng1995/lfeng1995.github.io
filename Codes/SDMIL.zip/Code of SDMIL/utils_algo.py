import numpy as np
import scipy.io as sio
import torch

def check_accuracy(clf, bags_test, aucplot):
    pred_score = np.array([clf(B.data()) for B in bags_test])
    pred_label = np.array([1 if score >= 0 else -1 for score in pred_score])
    true_label = np.array([B.y for B in bags_test])
    y      = np.array(pred_label)
    t      = np.array(true_label)
    tp     = len(list(filter(lambda z: z == +1, y[np.where(t == +1)])))
    fp     = len(list(filter(lambda z: z == +1, y[np.where(t == -1)])))
    fn     = len(list(filter(lambda z: z == -1, y[np.where(t == +1)])))
    tn     = len(list(filter(lambda z: z == -1, y[np.where(t == -1)])))
    acc    = (tp+tn)/(tp+tn+fp+fn)
    return acc

def baseline_accuracy_check(test_bags, model,device):
    true_label = np.array([B.y for B in test_bags])
    pred_label = np.zeros(len(test_bags))
    for i in range(len(test_bags)):
        data = test_bags[i].data()
        test_data = torch.from_numpy(data).float().to(device)
        output = model(test_data)
        if sum(output>0) == 0:
            pred_label[i] = -1
        else:
            pred_label[i] = 1
    total = len(true_label)
    num = (pred_label==true_label).sum()
    acc= num/total
    return acc

def minimax_basis(train_bags_without_label, degree):
    degree = int(degree)
    stat = lambda X: np.r_[X.min(axis=0), X.max(axis=0)]
    poly_kern = lambda X, Y: (stat(X).dot(stat(Y)) + 1) ** degree
    return lambda X: np.array([poly_kern(X, B) for B in train_bags_without_label])



