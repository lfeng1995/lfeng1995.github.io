
import torch
import torch.nn as nn

def ramp_loss(pred):
    return torch.clamp(1-pred,0,2)/2

def squared_loss(pred):
    return 1/4*torch.pow(pred-1,2)

def double_hinge_loss(pred):
    temp = 1/2 - 1/2*pred
    temp1 = torch.max(torch.tensor([0.0]), temp)
    temp2 = torch.max(-pred, temp1)
    return temp2

def hinge_loss(pred):
    return torch.clamp(1-pred,min=0)

def sigmoid_loss(pred):
    loss = torch.sigmoid(-pred)
    return loss

def logistic_loss(pred):
     negative_logistic = nn.LogSigmoid()
     logistic = -1. * negative_logistic(pred)
     return logistic

def exp_loss(pred):
    return torch.exp(-pred)


