from train_sts import *

datasets["num_work"] = 8
datasets["non_blocking"] = False
datasets["pin_memory"] = False

dataset_name = "sts"
loss_type = "lm"
max_interval = 3

datasets["epoch"] = 100
datasets["optim_rate"] = 0.001
datasets["batch_size"] = 256
out_dim = 1
if loss_type in ["CRM", "RANN", "SINN", "IN"]:
    out_dim = 2
metrics = ["mse", "mae", "pearsonr"]

load_data(dataset_name, max_interval)
best_model = train_sts(dataset_name, loss_type, metrics=metrics, print_show=True, out_dim=out_dim)

history = {loss_type: {}}
for metric in metrics:
    history[loss_type][metric] = []
for metric in metrics:
    loss_test = test_sts(best_model[metric], dataset_name, [metric], out_dim=out_dim)
    history[loss_type][metric].append(loss_test[metric])

print("dataset_name = {},max_interval = {},loss_type = {} complete".format(dataset_name, max_interval, loss_type))
print(history)
