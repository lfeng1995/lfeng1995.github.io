import torch
from itertools import permutations

class LLP_perm():
    def __init__(self,aggregate_labels,device,K):
        self.perm = []
        self.device = device
        for labels in aggregate_labels:
            self.perm.append(list(permutations(labels)))
        self.perm = torch.tensor(self.perm).to(device)
        self.K = K
        
    def generate_matrix(self,aggregate_labels):
        perm_matrix = torch.zeros(aggregate_labels.shape + (self.K,)).type(torch.LongTensor).to(self.device)
        src = torch.ones(aggregate_labels.shape + (1,)).type(torch.LongTensor).to(self.device)
        perm_matrix.scatter_(-1,aggregate_labels.unsqueeze(-1),src)
        return perm_matrix.to(self.device)
    
    def get_perm(self,index):
        aggregate_labels = self.perm[index]
        return aggregate_labels,self.generate_matrix(aggregate_labels)

        