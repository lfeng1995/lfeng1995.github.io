import matplotlib.pyplot as plt
import numpy as np


def plt_ablation(min, weights, name, l, line=1.0):
    plt.figure(figsize=(8, 7))
    plt.plot(min, 'or--', linewidth=line, label=l[0])
    plt.plot(weights, '*b--', linewidth=line, label=l[1])
    plt.xlabel('Size of training set', fontsize=28)
    plt.ylabel('Test loss (mean squared error)', fontsize=24)
    plt.xticks(range(5), ('20%', '40%', '60%', '80%', '100%'), fontsize=20)
    plt.yticks(fontsize=20)
    plt.legend(loc=1, fontsize=24)
    # plt.title('{}'.format(name), fontsize=20, fontweight='heavy')


color = ['b', 'g', 'r', 'c', 'm', 'y', 'k', 'w']

abalone_30 = np.array(
    [5.061696466418544, 4.882720327149167, 4.751014876707889, 4.689869082601447, 4.659947368859104])
abalone_40 = np.array(
    [5.509742033196408, 4.920281742634385, 4.822182854967254, 4.826006102037201, 4.818338441620603])

airfoil_30 = np.array(
    [23.59178047180176, 19.33640937805176, 19.179793548583984, 16.831922721862793, 16.722997093200682])
airfoil_40 = np.array(
    [25.357257843017578, 21.33889694213867, 19.65726547241211, 18.52501850128174, 18.310961532592774])

auto_mpg_30 = np.array(
    [14.725450897216797, 11.285453796386719, 10.29296646118164, 10.570563507080077, 9.629576683044434])
auto_mpg_40 = np.array(
    [17.113986015319824, 12.19287805557251, 11.334106731414796, 11.164248752593995, 11.109238529205323])

housing_30 = np.array(
    [44.281331634521486, 34.98242950439453, 27.749452590942383, 27.523649597167967, 22.133481216430664])
housing_40 = np.array(
    [51.161309814453126, 35.39716758728027, 31.446955108642577, 25.24991569519043, 24.533218383789062])

concrete_70 = np.array(
    [95.46820831298828, 66.12888641357422, 61.435977935791016, 57.61829452514648, 58.45430297851563])
concrete_80 = np.array(
    [103.28662109375, 72.03417205810547, 70.22596969604493, 63.18123931884766, 59.47653656005859])

power_plant_70 = np.array(
    [25.703609561023296, 24.730664127074814, 23.9400287596285, 23.955195572234246, 23.541254020459725])
power_plant_80 = np.array(
    [27.7119668308844, 27.067260994108988, 25.243928840342235, 24.83752516424645, 24.907604251411144])

plt_ablation(abalone_30, abalone_40, "Abalone", ["$q=30$", "$q=40$"],0.8)
# plt.show()
plt.savefig("abalone.pdf", bbox_inches='tight')


plt_ablation(airfoil_30, airfoil_40, "Airfoil", ["$q=30$", "$q=40$"],0.8)
# plt.show()
plt.savefig("airfoil.pdf", bbox_inches='tight')

plt_ablation(auto_mpg_30, auto_mpg_40, "Auto-mpg", ["$q=30$", "$q=40$"],0.8)
# plt.show()
plt.savefig("auto_mpg.pdf", bbox_inches='tight')

plt_ablation(housing_30, housing_40, "Housing", ["$q=30$", "$q=40$"],0.8)
# plt.show()
plt.savefig("housing.pdf", bbox_inches='tight')

plt_ablation(concrete_70, concrete_80, "Concrete", ["$q=70$", "$q=80$"],0.8)
# plt.show()
plt.savefig("concrete.pdf", bbox_inches='tight')

plt_ablation(power_plant_70, power_plant_80, "Power-plant", ["$q=60$", "$q=70$"],0.8)
# plt.show()
plt.savefig("power_plant.pdf", bbox_inches='tight')