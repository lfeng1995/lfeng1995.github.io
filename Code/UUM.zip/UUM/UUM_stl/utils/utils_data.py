import numpy as np
import torch
import torchvision.transforms as transforms
import torchvision.datasets as dsets
from scipy.special import comb
from utils.gen_index_dataset import gen_index_dataset, ClaDataset
from numpy.testing import assert_array_almost_equal
import scipy.io as scio
import os



def sample_with_replacement(n: int, k: int, size: int) -> np.ndarray:
    return torch.tensor(np.random.choice(n, size * k).reshape(size, k))


def sample_without_replacement_within_sets(n: int, k: int, size: int) -> np.ndarray:
    return torch.tensor(np.stack([np.random.choice(n, k, replace=False) for _ in range(size)]))


def sample_without_replacement(n: int, k: int, size: int) -> np.ndarray:
    return torch.tensor(np.random.choice(n, size * k, replace=False).reshape(size, k))

def prepare_datasets(dataname, batch_size,seed):
    instance_dim = -1
    if dataname == 'mnist':
        ordinary_train_dataset = dsets.MNIST(root='./data/mnist', train=True, transform=transforms.ToTensor(), download=True)
        test_dataset = dsets.MNIST(root='./data/mnist', train=False, transform=transforms.ToTensor())
        K = torch.max(ordinary_train_dataset.targets) - torch.min(ordinary_train_dataset.targets) + 1
    elif dataname == 'kmnist':
        ordinary_train_dataset = dsets.KMNIST(root='./data/KMNIST', train=True, transform=transforms.ToTensor(), download=True)
        test_dataset = dsets.KMNIST(root='./data/KMNIST', train=False, transform=transforms.ToTensor())
        K = torch.max(ordinary_train_dataset.targets) - torch.min(ordinary_train_dataset.targets) + 1
    elif dataname == 'fashion':
        ordinary_train_dataset = dsets.FashionMNIST(root='./data/FashionMnist', train=True, transform=transforms.ToTensor(), download=True)
        test_dataset = dsets.FashionMNIST(root='./data/FashionMnist', train=False, transform=transforms.ToTensor())
        K = torch.max(ordinary_train_dataset.targets) - torch.min(ordinary_train_dataset.targets) + 1
    elif dataname == 'cifar10':
        ordinary_train_dataset = dsets.CIFAR10(root='./data/cifar10', train=True, transform=transforms.ToTensor(), download=True)
        test_dataset = dsets.CIFAR10(root='./data/cifar10', train=False, transform=transforms.ToTensor())
        K = 10
    elif dataname == 'SVHN':
        ordinary_train_dataset = dsets.SVHN(root='./data/SVHN', split='train', transform=transforms.ToTensor(), download=True)
        test_dataset = dsets.SVHN(root='./data/SVHN',split='test', transform=transforms.ToTensor())
        K = 10
    train_loader, val_loader, full_train_loader = split_train_val_dataset(ordinary_train_dataset,batch_size)
    test_loader = torch.utils.data.DataLoader(dataset=test_dataset, batch_size=batch_size, shuffle=False, num_workers=0)
    print('train dataset size:%s, val dataset size:%s, test dataset size:%s'%(int(0.75*ordinary_train_dataset.__len__()),ordinary_train_dataset.__len__()-int(0.75*ordinary_train_dataset.__len__()),test_dataset.__len__()))
    return train_loader, val_loader, test_loader, full_train_loader, instance_dim, K

def split_train_val_dataset(dataset,batchsize):
    lengths = [int(0.75*len(dataset)),len(dataset)-int(0.75*len(dataset))]
    train_dataset, val_dataset = torch.utils.data.random_split(dataset=dataset,lengths=lengths)
    train_loader = torch.utils.data.DataLoader(dataset=train_dataset,batch_size=batchsize,shuffle=True,num_workers=0)
    val_loader = torch.utils.data.DataLoader(dataset=val_dataset,batch_size=batchsize,shuffle=True,num_workers=0)
    full_train_loader = torch.utils.data.DataLoader(dataset=train_dataset, batch_size=train_dataset.__len__(), shuffle=True, num_workers=0)
    return train_loader, val_loader, full_train_loader
 
def generate_aggreate_dataset(full_train_loader, size, size_m, sample_option, aggreate_function,task):
    for data, labels in full_train_loader:
        pass
    if task in ['similarity,triplet','triplet1side'] and torch.min(labels) > 1:
        raise RuntimeError('testError')
    elif torch.min(labels) == 1:
        labels = labels - 1
    n = len(labels)
    if sample_option == 'rep':
        aggreate_index = sample_with_replacement(n,size_m,size)
    elif sample_option == 'nrep_within_set':
        aggreate_index = sample_without_replacement_within_sets(n, size_m, size)
    elif sample_option == 'nrep':
        aggreate_index = sample_without_replacement(n, size_m, size)
    aggreate_labels = torch.gather(labels.reshape(-1,1).expand(-1,size_m),0,aggreate_index)
    aggreate_labels = aggreate_function(aggreate_labels)
    if len(data.shape)==1:
        data = torch.gather(data.reshape(-1,1).expand(-1,size_m),0,aggreate_index)
    if len(data.shape)>=2:
        # let the shape of aggreate_index same as data
        data.unsqueeze_(1)
        data = data.expand((-1,size_m)+(len(data.shape)-2)*(-1,))
        aggreate_index = aggreate_index.reshape(aggreate_index.shape + (len(data.shape)-len(aggreate_index.shape))*(1,))
        aggreate_index = aggreate_index.expand((-1,-1)+data.shape[2:])
        data = torch.gather(data, 0, aggreate_index)
    return data, aggreate_labels
    
    