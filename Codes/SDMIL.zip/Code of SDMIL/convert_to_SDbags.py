import numpy as np
from utils_data import extract_bags

def convert_to_SDbags(bags, theta, M, args):
    p_bags = extract_bags(bags,  1, with_label = True) # list type
    n_bags = extract_bags(bags, -1, with_label = True)
    np.random.shuffle(p_bags)
    np.random.shuffle(n_bags)
    P = len(p_bags)
    N = len(n_bags)
    S = int(M*(1-2*theta*(1-theta))/2) # we assume M = 2*S+2*D
    D = int((M - 2*S)/2)
    if D%2 != 0: D=D-1; S=S+1
    SP = int(S*(theta**2/(theta**2 + (1-theta)**2)))
    SN = S - SP
    DP = int(0.5*D)
    DN = D - DP
    num_TP = P - 2*(SP+DP)
    num_TN = N - 2*(SN+DN)
    num_T1 = int(num_TP/theta)
    num_T2 = int(num_TN/(1-theta))
    if num_T1 <=num_T2:
        TP = num_TP
        TN = num_T1 - TP
    else:
        TN = num_TN
        TP = num_T2 - TN
    assert 2*(SP+DP)+TP<=P, "Insufficient positive bags!"
    assert 2*(SN+DN)+TN<=N, "Insufficient negative bags!"
    assert DP == DN, "Invalid dissimilar pairs!"

    s1_bags = p_bags[:SP] + n_bags[:SN] #[:int(SP*args.num_rate)]
    s2_bags = p_bags[SP:2*SP] + n_bags[SN:2*SN]
    d1_bags = p_bags[2*SP:(2*SP+DP)]  + n_bags[2*SN:(2*SN+DN)]
    d2_bags = n_bags[(2*SN+DN):2*(SN+DN)] + p_bags[(2*SP+DP):2*(SP+DP)]
    test_bags = p_bags[2*(SP+DP): (2*(SP+DP)+TP)] + n_bags[2*(SN+DN): (2*(SN+DN)+TN)]
#    print(len(s1_bags), len(s2_bags),len(d1_bags),len(d2_bags),len(test_bags))
    return s1_bags, s2_bags, d1_bags, d2_bags, test_bags


